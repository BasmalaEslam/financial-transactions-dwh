/*
===============================================================================
 Create Database and Schemas
===============================================================================
 Purpose:
   Creates the 'FinanceDWH' database (only if it does not exist yet) and the
   three layer schemas: bronze, silver and gold.

 Notes:
   - Safe to re-run: this script does not drop anything.
   - Recovery model is set to SIMPLE so the transaction log stays small while
     we load millions of rows (point-in-time restore is not needed here).
===============================================================================
*/

USE master;
GO

IF DB_ID(N'FinanceDWH') IS NULL
    CREATE DATABASE FinanceDWH;
GO

ALTER DATABASE FinanceDWH SET RECOVERY SIMPLE;
GO

USE FinanceDWH;
GO

-- CREATE SCHEMA must be alone in its batch, so it runs through EXEC
IF SCHEMA_ID(N'bronze') IS NULL EXEC (N'CREATE SCHEMA bronze');
IF SCHEMA_ID(N'silver') IS NULL EXEC (N'CREATE SCHEMA silver');
IF SCHEMA_ID(N'gold')   IS NULL EXEC (N'CREATE SCHEMA gold');
GO

-- Check: should return 3 rows (bronze, gold, silver)
SELECT name AS schema_name
FROM sys.schemas
WHERE name IN (N'bronze', N'silver', N'gold')
ORDER BY name;
GO
