/*
===============================================================================
 Stored Procedure: Load Gold Layer (Silver -> Gold star schema)
===============================================================================
 Purpose:
   Full load of the gold dimensions and facts from silver.
   For each table it truncates the table, inserts the rows, then prints the
   row count and the time it took. Dimensions load first, then facts.

 Usage:
   EXEC gold.load_gold;
===============================================================================
*/

USE FinanceDWH;
GO

CREATE OR ALTER PROCEDURE gold.load_gold
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @row_count   BIGINT,
            @start_time  DATETIME2(0),
            @batch_start DATETIME2(0) = SYSDATETIME(),
            @date_from   DATE,
            @date_to     DATE;

    BEGIN TRY
        PRINT '===============================================';
        PRINT 'Loading Gold Layer';
        PRINT '===============================================';

        -----------------------------------------------------------------------
        -- 1) dim_date : full years that cover all transactions
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_date;

        SELECT @date_from = DATEFROMPARTS(YEAR(MIN(transaction_date)), 1, 1),
               @date_to   = DATEFROMPARTS(YEAR(MAX(transaction_date)), 12, 31)
        FROM silver.transactions;

        WITH numbers AS (
            SELECT TOP (DATEDIFF(DAY, @date_from, @date_to) + 1)
                   ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS n
            FROM sys.all_objects AS a
            CROSS JOIN sys.all_objects AS b
        )
        INSERT INTO gold.dim_date (
            date_key, full_date, year, quarter, quarter_name,
            month_number, month_name, month_short, year_month, year_month_key,
            day_of_month, day_of_week, day_name, day_short, day_type
        )
        SELECT
            YEAR(d.full_date) * 10000 + MONTH(d.full_date) * 100 + DAY(d.full_date),
            d.full_date,
            YEAR(d.full_date),
            DATEPART(QUARTER, d.full_date),
            CONCAT('Q', DATEPART(QUARTER, d.full_date)),
            MONTH(d.full_date),
            CHOOSE(MONTH(d.full_date), 'January', 'February', 'March', 'April', 'May', 'June',
                   'July', 'August', 'September', 'October', 'November', 'December'),
            CHOOSE(MONTH(d.full_date), 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                   'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'),
            CONCAT(YEAR(d.full_date), '-', RIGHT(CONCAT('0', MONTH(d.full_date)), 2)),
            YEAR(d.full_date) * 100 + MONTH(d.full_date),
            DAY(d.full_date),
            w.dow,
            CHOOSE(w.dow, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
            CHOOSE(w.dow, 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'),
            CASE WHEN w.dow IN (6, 7) THEN 'Weekend' ELSE 'Weekday' END
        FROM numbers
        CROSS APPLY (SELECT DATEADD(DAY, numbers.n, @date_from) AS full_date) AS d
        -- 1900-01-01 was a Monday, so this gives 1 = Monday .. 7 = Sunday
        -- (it does not depend on the server's DATEFIRST setting)
        CROSS APPLY (SELECT DATEDIFF(DAY, '19000101', d.full_date) % 7 + 1 AS dow) AS w;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_date;
        PRINT '>> gold.dim_date                : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 2) dim_customer : with age group, income band, credit band
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_customer;

        INSERT INTO gold.dim_customer (
            customer_key, gender, current_age, age_group, age_group_sort,
            birth_year, retirement_age, yearly_income, income_band, income_band_sort,
            per_capita_income, total_debt, credit_score, credit_band, credit_band_sort,
            num_credit_cards, latitude, longitude
        )
        SELECT
            u.customer_id,
            u.gender,
            u.current_age,
            CHOOSE(b.age_sort, '18-24', '25-34', '35-44', '45-54', '55-64', '65+'),
            b.age_sort,
            u.birth_year,
            u.retirement_age,
            u.yearly_income,
            CHOOSE(b.income_sort, '<25K', '25K-50K', '50K-75K', '75K-100K', '100K+'),
            b.income_sort,
            u.per_capita_income,
            u.total_debt,
            u.credit_score,
            -- FICO score ranges
            CHOOSE(b.credit_sort, 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent'),
            b.credit_sort,
            u.num_credit_cards,
            u.latitude,
            u.longitude
        FROM silver.users AS u
        CROSS APPLY (
            SELECT
                CASE
                    WHEN u.current_age IS NULL THEN NULL
                    WHEN u.current_age < 25 THEN 1
                    WHEN u.current_age < 35 THEN 2
                    WHEN u.current_age < 45 THEN 3
                    WHEN u.current_age < 55 THEN 4
                    WHEN u.current_age < 65 THEN 5
                    ELSE 6
                END AS age_sort,
                CASE
                    WHEN u.yearly_income IS NULL THEN NULL
                    WHEN u.yearly_income < 25000  THEN 1
                    WHEN u.yearly_income < 50000  THEN 2
                    WHEN u.yearly_income < 75000  THEN 3
                    WHEN u.yearly_income < 100000 THEN 4
                    ELSE 5
                END AS income_sort,
                CASE
                    WHEN u.credit_score IS NULL THEN NULL
                    WHEN u.credit_score < 580 THEN 1
                    WHEN u.credit_score < 670 THEN 2
                    WHEN u.credit_score < 740 THEN 3
                    WHEN u.credit_score < 800 THEN 4
                    ELSE 5
                END AS credit_sort
        ) AS b;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_customer;
        PRINT '>> gold.dim_customer            : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 3) dim_card
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_card;

        INSERT INTO gold.dim_card (
            card_key, customer_key, card_brand, card_type, has_chip,
            num_cards_issued, credit_limit, acct_open_date, acct_open_year,
            expires_date, year_pin_last_changed
        )
        SELECT
            card_id,
            customer_id,
            card_brand,
            card_type,
            CASE has_chip WHEN 1 THEN 'Yes' WHEN 0 THEN 'No' END,
            num_cards_issued,
            credit_limit,
            acct_open_date,
            YEAR(acct_open_date),
            expires_date,
            year_pin_last_changed
        FROM silver.cards;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_card;
        PRINT '>> gold.dim_card                : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 4) dim_mcc : 109 codes grouped into 14 categories
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_mcc;

        INSERT INTO gold.dim_mcc (mcc_key, mcc_description, mcc_category)
        SELECT
            mcc,
            description,
            CASE
                WHEN mcc IN (5300, 5411, 5499, 5921)
                    THEN 'Groceries & Food Stores'
                WHEN mcc IN (5812, 5813, 5814)
                    THEN 'Restaurants & Bars'
                WHEN mcc IN (5533, 5541, 7531, 7538, 7542, 7549)
                    THEN 'Fuel & Automotive'
                WHEN mcc IN (3722, 3771, 3775, 4111, 4112, 4121, 4131, 4214, 4784)
                    THEN 'Transportation'
                WHEN mcc IN (4411, 4511, 4722, 7011)
                    THEN 'Travel & Lodging'
                WHEN mcc IN (3132, 5094, 5192, 5193, 5310, 5311, 5621, 5651, 5655,
                             5661, 5932, 5941, 5942, 5947, 5970, 5977)
                    THEN 'Retail Shopping'
                WHEN mcc IN (5045, 5732, 5733, 5815, 5816)
                    THEN 'Electronics & Digital'
                WHEN mcc IN (1711, 3144, 3174, 3256, 3260, 3504, 3640, 5211, 5251,
                             5261, 5712, 5719, 5722)
                    THEN 'Home & Garden'
                WHEN mcc IN (5912, 8011, 8021, 8041, 8043, 8049, 8062, 8099)
                    THEN 'Health & Medical'
                WHEN mcc IN (3780, 4814, 4899, 4900, 6300)
                    THEN 'Bills & Utilities'
                WHEN mcc IN (4829, 7276, 8111, 8931)
                    THEN 'Money & Professional'
                WHEN mcc IN (7801, 7802, 7832, 7922, 7995, 7996)
                    THEN 'Entertainment'
                WHEN mcc IN (7210, 7230, 7349, 7393, 9402)
                    THEN 'Personal Services'
                WHEN mcc IN (3000, 3001, 3005, 3006, 3007, 3008, 3009, 3058, 3066,
                             3075, 3359, 3387, 3389, 3390, 3393, 3395, 3405, 3509,
                             3596, 3684, 3730)
                    THEN 'Industrial & Manufacturing'
                ELSE 'Other'
            END
        FROM silver.mcc_codes;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_mcc;
        PRINT '>> gold.dim_mcc                 : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 5) dim_location : distinct merchant locations
        --    location_code must be built the same way in the fact load below
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_location;   -- also resets the IDENTITY

        INSERT INTO gold.dim_location (location_type, country, state, city, zip, location_code)
        SELECT
            x.location_type,
            x.country,
            x.state,
            x.city,
            x.zip,
            CONCAT(x.location_type, '|', x.country, '|', ISNULL(x.state, ''), '|',
                   x.city, '|', ISNULL(x.zip, ''))
        FROM (
            SELECT DISTINCT
                t.location_type,
                ISNULL(t.merchant_country, 'Online') AS country,
                t.merchant_state AS state,
                t.merchant_city  AS city,
                t.merchant_zip   AS zip
            FROM silver.transactions AS t
        ) AS x
        ORDER BY x.location_type, x.country, x.state, x.city, x.zip;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_location;
        PRINT '>> gold.dim_location            : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 6) dim_channel
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_channel;

        INSERT INTO gold.dim_channel (channel_key, channel_name)
        SELECT DISTINCT
            CASE channel WHEN 'Swipe' THEN 1 WHEN 'Chip' THEN 2 WHEN 'Online' THEN 3 ELSE 9 END,
            channel
        FROM silver.transactions;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_channel;
        PRINT '>> gold.dim_channel             : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 7) fact_transactions  (13.3M rows)
        --    LEFT JOIN on purpose: a missing location would hit the NOT NULL
        --    rule and stop the load, instead of silently dropping rows.
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.fact_transactions;

        INSERT INTO gold.fact_transactions WITH (TABLOCK) (
            transaction_id, date_key, transaction_hour, customer_key, card_key,
            location_key, mcc_key, channel_key, merchant_id, amount,
            is_refund, has_error, fraud_status, is_fraud
        )
        SELECT
            t.transaction_id,
            YEAR(t.transaction_date) * 10000 + MONTH(t.transaction_date) * 100 + DAY(t.transaction_date),
            DATEPART(HOUR, t.transaction_datetime),
            t.customer_id,
            t.card_id,
            l.location_key,
            t.mcc,
            CASE t.channel WHEN 'Swipe' THEN 1 WHEN 'Chip' THEN 2 WHEN 'Online' THEN 3 ELSE 9 END,
            t.merchant_id,
            t.amount,
            t.is_refund,
            t.has_error,
            CASE f.is_fraud WHEN 1 THEN 'Fraud' WHEN 0 THEN 'Legit' ELSE 'Unlabeled' END,
            f.is_fraud
        FROM silver.transactions AS t
        LEFT JOIN gold.dim_location AS l
            ON l.location_code = CONCAT(t.location_type, '|', ISNULL(t.merchant_country, 'Online'), '|',
                                        ISNULL(t.merchant_state, ''), '|', t.merchant_city, '|',
                                        ISNULL(t.merchant_zip, ''))
        LEFT JOIN silver.fraud_labels AS f
            ON f.transaction_id = t.transaction_id;

        SELECT @row_count = COUNT_BIG(*) FROM gold.fact_transactions;
        PRINT '>> gold.fact_transactions       : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 8) fact_transaction_errors : same keys as the transaction
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.fact_transaction_errors;

        INSERT INTO gold.fact_transaction_errors WITH (TABLOCK) (
            transaction_id, error_type, date_key, customer_key, card_key,
            location_key, mcc_key, channel_key, amount
        )
        SELECT
            e.transaction_id,
            e.error_type,
            f.date_key,
            f.customer_key,
            f.card_key,
            f.location_key,
            f.mcc_key,
            f.channel_key,
            f.amount
        FROM silver.transaction_errors AS e
        JOIN gold.fact_transactions AS f
            ON f.transaction_id = e.transaction_id;

        SELECT @row_count = COUNT_BIG(*) FROM gold.fact_transaction_errors;
        PRINT '>> gold.fact_transaction_errors : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        PRINT '===============================================';
        PRINT 'Gold Layer loaded in '
              + CAST(DATEDIFF(SECOND, @batch_start, SYSDATETIME()) AS VARCHAR(20)) + ' sec';
        PRINT '===============================================';
    END TRY
    BEGIN CATCH
        PRINT '===============================================';
        PRINT 'ERROR while loading the Gold Layer';
        PRINT 'Message : ' + ERROR_MESSAGE();
        PRINT 'Number  : ' + CAST(ERROR_NUMBER() AS VARCHAR(20));
        PRINT '===============================================';
        THROW;
    END CATCH
END;
GO
