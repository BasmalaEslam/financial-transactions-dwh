/*
===============================================================================
 Quality Checks: Gold Layer
===============================================================================
 Run after: EXEC gold.load_gold;
 Every row should show result = 'OK'.
 Expected numbers were counted from the raw files with the same rules.
===============================================================================
*/

USE FinanceDWH;
GO

SELECT check_id,
       check_name,
       expected,
       actual,
       CASE WHEN expected = actual THEN 'OK' ELSE 'CHECK' END AS result
FROM (
    ---------------------------------------------------------------------------
    -- Row counts
    ---------------------------------------------------------------------------
    SELECT 1 AS check_id, 'dim_date: row count (2010-2019)' AS check_name,
           CAST(3652 AS BIGINT) AS expected,
           (SELECT COUNT_BIG(*) FROM gold.dim_date) AS actual
    UNION ALL
    SELECT 2, 'dim_customer: row count', 2000,
           (SELECT COUNT_BIG(*) FROM gold.dim_customer)
    UNION ALL
    SELECT 3, 'dim_card: row count', 6146,
           (SELECT COUNT_BIG(*) FROM gold.dim_card)
    UNION ALL
    SELECT 4, 'dim_mcc: row count', 109,
           (SELECT COUNT_BIG(*) FROM gold.dim_mcc)
    UNION ALL
    SELECT 5, 'dim_mcc: codes without a category', 0,
           (SELECT COUNT_BIG(*) FROM gold.dim_mcc WHERE mcc_category = 'Other')
    UNION ALL
    SELECT 6, 'dim_location: row count', 25425,
           (SELECT COUNT_BIG(*) FROM gold.dim_location)
    UNION ALL
    SELECT 7, 'dim_channel: row count', 3,
           (SELECT COUNT_BIG(*) FROM gold.dim_channel)
    UNION ALL
    SELECT 8, 'fact_transactions: row count', 13305915,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions)
    UNION ALL
    SELECT 9, 'fact_transaction_errors: row count', 212335,
           (SELECT COUNT_BIG(*) FROM gold.fact_transaction_errors)

    ---------------------------------------------------------------------------
    -- Every fact key exists in its dimension
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 10, 'fact: date_key not in dim_date', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_date AS d WHERE d.date_key = f.date_key))
    UNION ALL
    SELECT 11, 'fact: customer_key not in dim_customer', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_customer AS d WHERE d.customer_key = f.customer_key))
    UNION ALL
    SELECT 12, 'fact: card_key not in dim_card', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_card AS d WHERE d.card_key = f.card_key))
    UNION ALL
    SELECT 13, 'fact: location_key not in dim_location', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_location AS d WHERE d.location_key = f.location_key))
    UNION ALL
    SELECT 14, 'fact: mcc_key not in dim_mcc', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_mcc AS d WHERE d.mcc_key = f.mcc_key))
    UNION ALL
    SELECT 15, 'fact: channel_key not in dim_channel', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_channel AS d WHERE d.channel_key = f.channel_key))
    UNION ALL
    SELECT 16, 'errors fact: transaction not in fact_transactions', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transaction_errors AS e
            WHERE NOT EXISTS (SELECT 1 FROM gold.fact_transactions AS f WHERE f.transaction_id = e.transaction_id))

    ---------------------------------------------------------------------------
    -- Business numbers (match the source files)
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 17, 'fact: total amount in cents', 57183552228,
           (SELECT CAST(SUM(amount) * 100 AS BIGINT) FROM gold.fact_transactions)
    UNION ALL
    SELECT 18, 'fact: refund transactions', 660049,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions WHERE is_refund = 1)
    UNION ALL
    SELECT 19, 'fact: transactions with errors', 211393,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions WHERE has_error = 1)
    UNION ALL
    SELECT 20, 'fact: fraud_status = Fraud', 13332,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions WHERE fraud_status = 'Fraud')
    UNION ALL
    SELECT 21, 'fact: fraud_status = Legit', 8901631,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions WHERE fraud_status = 'Legit')
    UNION ALL
    SELECT 22, 'fact: fraud_status = Unlabeled', 4390952,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions WHERE fraud_status = 'Unlabeled')
) AS c
ORDER BY check_id;
GO
