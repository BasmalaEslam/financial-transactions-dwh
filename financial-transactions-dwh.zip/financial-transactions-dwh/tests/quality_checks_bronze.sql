/*
===============================================================================
 Quality Checks: Bronze Layer
===============================================================================
 Run after: EXEC bronze.load_bronze;
 Every row should show result = 'OK'.
 The expected numbers were counted directly from the raw source files.
===============================================================================
*/

USE FinanceDWH;
GO

SELECT check_id,
       check_name,
       expected,
       actual,
       CASE WHEN expected = actual THEN 'OK' ELSE 'CHECK' END AS result
FROM (
    -- Row counts: every data row of each file is loaded (header row skipped)
    SELECT 1 AS check_id,
           'users_data: row count' AS check_name,
           CAST(2000 AS BIGINT) AS expected,
           (SELECT COUNT_BIG(*) FROM bronze.users_data) AS actual
    UNION ALL
    SELECT 2, 'cards_data: row count', 6146,
           (SELECT COUNT_BIG(*) FROM bronze.cards_data)
    UNION ALL
    SELECT 3, 'transactions_data: row count', 13305915,
           (SELECT COUNT_BIG(*) FROM bronze.transactions_data)
    UNION ALL
    SELECT 4, 'mcc_codes: row count', 109,
           (SELECT COUNT_BIG(*) FROM bronze.mcc_codes)
    UNION ALL
    SELECT 5, 'train_fraud_labels: row count', 8914963,
           (SELECT COUNT_BIG(*) FROM bronze.train_fraud_labels)

    -- Parsing: the file formats were read correctly
    UNION ALL
    SELECT 6, 'train_fraud_labels: is_fraud = Yes', 13332,
           (SELECT COUNT_BIG(*) FROM bronze.train_fraud_labels WHERE is_fraud = 'Yes')
    UNION ALL
    SELECT 7, 'cards_data: hidden CR left at line end', 0,
           (SELECT COUNT_BIG(*) FROM bronze.cards_data WHERE card_on_dark_web LIKE '%' + CHAR(13) + '%')
    UNION ALL
    SELECT 8, 'transactions_data: amount starts with $ (columns in place)', 13305915,
           (SELECT COUNT_BIG(*) FROM bronze.transactions_data WHERE amount LIKE '$%')
    UNION ALL
    SELECT 9, 'transactions_data: quoted multi-errors kept as one value', 941,
           (SELECT COUNT_BIG(*) FROM bronze.transactions_data WHERE errors LIKE '%,%')
    UNION ALL
    SELECT 10, 'transactions_data: quote chars left in errors', 0,
           (SELECT COUNT_BIG(*) FROM bronze.transactions_data WHERE errors LIKE '%"%')
) AS c
ORDER BY check_id;
GO
