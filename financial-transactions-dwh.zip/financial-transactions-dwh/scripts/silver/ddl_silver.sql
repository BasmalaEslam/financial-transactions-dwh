/*
===============================================================================
 DDL Script: Create Silver Tables
===============================================================================
 Purpose:
   Creates the silver tables. Silver holds cleaned and typed data:
     - real data types (INT, DECIMAL, DATE, BIT) instead of text
     - '$' signs removed, ZIP codes fixed, flags added
     - sensitive card data (card_number, cvv) is not carried over
     - multi-value errors are split into silver.transaction_errors

 Warning:
   Re-running this script drops and re-creates the silver tables.
   Reload them after that with: EXEC silver.load_silver;
===============================================================================
*/

USE FinanceDWH;
GO

-------------------------------------------------------------------------------
-- silver.users  (source: bronze.users_data)
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.users;
GO

CREATE TABLE silver.users (
    customer_id        INT            NOT NULL,
    current_age        TINYINT,
    retirement_age     TINYINT,
    birth_year         SMALLINT,
    birth_month        TINYINT,
    gender             VARCHAR(10),
    address            VARCHAR(100),
    latitude           DECIMAL(8,4),
    longitude          DECIMAL(8,4),
    per_capita_income  DECIMAL(12,2),   -- 0 in the source means unknown -> NULL
    yearly_income      DECIMAL(12,2),
    total_debt         DECIMAL(12,2),
    credit_score       SMALLINT,
    num_credit_cards   TINYINT,
    dwh_create_date    DATETIME2(0)   DEFAULT SYSDATETIME()
);
GO

-------------------------------------------------------------------------------
-- silver.cards  (source: bronze.cards_data)
-- Not carried over: card_number and cvv (sensitive), card_on_dark_web
-- (same value 'No' for every card).
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.cards;
GO

CREATE TABLE silver.cards (
    card_id                INT           NOT NULL,
    customer_id            INT,
    card_brand             VARCHAR(20),
    card_type              VARCHAR(20),
    has_chip               BIT,
    num_cards_issued       TINYINT,
    credit_limit           DECIMAL(12,2),
    expires_date           DATE,          -- last day of the expiry month
    acct_open_date         DATE,          -- first day of the opening month
    year_pin_last_changed  SMALLINT,
    dwh_create_date        DATETIME2(0)  DEFAULT SYSDATETIME()
);
GO

-------------------------------------------------------------------------------
-- silver.transactions  (source: bronze.transactions_data)
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.transactions;
GO

CREATE TABLE silver.transactions (
    transaction_id        INT           NOT NULL,
    transaction_datetime  DATETIME2(0),
    transaction_date      DATE,
    customer_id           INT,
    card_id               INT,
    amount                DECIMAL(12,2),
    is_refund             BIT,           -- 1 when amount < 0
    channel               VARCHAR(10),   -- Swipe / Chip / Online
    merchant_id           INT,
    is_online             BIT,           -- 1 when merchant_city = 'ONLINE'
    location_type         VARCHAR(15),   -- Online / United States / International
    merchant_city         VARCHAR(50),
    merchant_state        CHAR(2),       -- US state code only
    merchant_zip          CHAR(5),       -- 5 digits with leading zeros
    merchant_country      VARCHAR(50),   -- NULL for online merchants
    mcc                   SMALLINT,
    errors                VARCHAR(100),  -- NULL = no error
    has_error             BIT,
    dwh_create_date       DATETIME2(0)  DEFAULT SYSDATETIME()
);
GO

-------------------------------------------------------------------------------
-- silver.mcc_codes  (source: bronze.mcc_codes)
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.mcc_codes;
GO

CREATE TABLE silver.mcc_codes (
    mcc              SMALLINT      NOT NULL,
    description      VARCHAR(100),
    dwh_create_date  DATETIME2(0)  DEFAULT SYSDATETIME()
);
GO

-------------------------------------------------------------------------------
-- silver.fraud_labels  (source: bronze.train_fraud_labels)
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.fraud_labels;
GO

CREATE TABLE silver.fraud_labels (
    transaction_id   INT           NOT NULL,
    is_fraud         BIT,
    dwh_create_date  DATETIME2(0)  DEFAULT SYSDATETIME()
);
GO

-------------------------------------------------------------------------------
-- silver.transaction_errors  (one row per transaction per error)
-- Built from silver.transactions.errors, e.g. 'Bad PIN,Insufficient Balance'
-- becomes 2 rows.
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.transaction_errors;
GO

CREATE TABLE silver.transaction_errors (
    transaction_id   INT           NOT NULL,
    error_type       VARCHAR(50)   NOT NULL,
    dwh_create_date  DATETIME2(0)  DEFAULT SYSDATETIME()
);
GO
