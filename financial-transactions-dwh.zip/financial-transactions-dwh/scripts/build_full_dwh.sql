/*
===============================================================================
 BUILD THE FULL DATA WAREHOUSE (one click)
===============================================================================
 What it does, in order:
   1. Creates the FinanceDWH database and the bronze / silver / gold schemas
   2. Creates all tables and the 3 load procedures
   3. Runs the ETL: bronze.load_bronze -> silver.load_silver -> gold.load_gold
   4. Runs the quality checks (3 result grids, every row should say OK)

 Before you run it:
   - The 5 source files must be in C:\DWH\datasets\
     (if they are somewhere else, change the folder in the EXEC line below,
      search for: @data_path)
   - Press F5. It takes a few minutes (13.3M transactions).

 Generated from the scripts in this folder. Edit those files, not this one.
===============================================================================
*/


-- #############################################################################
-- FILE: scripts/init_database.sql
-- #############################################################################
/*
===============================================================================
 Create Database and Schemas
===============================================================================
 Purpose:
   Creates the 'FinanceDWH' database (only if it does not exist yet) and the
   three layer schemas: bronze, silver and gold.

 Notes:
   - Safe to re-run: this script does not drop anything.
   - Recovery model is set to SIMPLE so the transaction log stays small while
     we load millions of rows (point-in-time restore is not needed here).
===============================================================================
*/

USE master;
GO

IF DB_ID(N'FinanceDWH') IS NULL
    CREATE DATABASE FinanceDWH;
GO

ALTER DATABASE FinanceDWH SET RECOVERY SIMPLE;
GO

USE FinanceDWH;
GO

-- CREATE SCHEMA must be alone in its batch, so it runs through EXEC
IF SCHEMA_ID(N'bronze') IS NULL EXEC (N'CREATE SCHEMA bronze');
IF SCHEMA_ID(N'silver') IS NULL EXEC (N'CREATE SCHEMA silver');
IF SCHEMA_ID(N'gold')   IS NULL EXEC (N'CREATE SCHEMA gold');
GO

-- Check: should return 3 rows (bronze, gold, silver)
SELECT name AS schema_name
FROM sys.schemas
WHERE name IN (N'bronze', N'silver', N'gold')
ORDER BY name;
GO

-- #############################################################################
-- FILE: scripts/bronze/ddl_bronze.sql
-- #############################################################################
/*
===============================================================================
 DDL Script: Create Bronze Tables
===============================================================================
 Purpose:
   Creates one bronze table per source file. Bronze is a raw copy of the files:
   every column is VARCHAR, so values land exactly as they are in the source
   (for example '$-77.00', '58523.0', '09/2002'). Data types and cleaning
   happen later in the Silver layer.

 Warning:
   Re-running this script drops and re-creates the bronze tables.
   Reload them after that with: EXEC bronze.load_bronze;
===============================================================================
*/

USE FinanceDWH;
GO

-------------------------------------------------------------------------------
-- users_data.csv : 2,000 rows, one row per client
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS bronze.users_data;
GO

CREATE TABLE bronze.users_data (
    id                 VARCHAR(10),
    current_age        VARCHAR(10),
    retirement_age     VARCHAR(10),
    birth_year         VARCHAR(10),
    birth_month        VARCHAR(10),
    gender             VARCHAR(20),
    address            VARCHAR(100),
    latitude           VARCHAR(20),
    longitude          VARCHAR(20),
    per_capita_income  VARCHAR(20),
    yearly_income      VARCHAR(20),
    total_debt         VARCHAR(20),
    credit_score       VARCHAR(10),
    num_credit_cards   VARCHAR(10)
);
GO

-------------------------------------------------------------------------------
-- cards_data.csv : 6,146 rows, one row per card
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS bronze.cards_data;
GO

CREATE TABLE bronze.cards_data (
    id                     VARCHAR(10),
    client_id              VARCHAR(10),
    card_brand             VARCHAR(20),
    card_type              VARCHAR(30),
    card_number            VARCHAR(25),
    expires                VARCHAR(10),
    cvv                    VARCHAR(10),
    has_chip               VARCHAR(10),
    num_cards_issued       VARCHAR(10),
    credit_limit           VARCHAR(20),
    acct_open_date         VARCHAR(10),
    year_pin_last_changed  VARCHAR(10),
    card_on_dark_web       VARCHAR(10)
);
GO

-------------------------------------------------------------------------------
-- transactions_data.csv : 13,305,915 rows, one row per transaction
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS bronze.transactions_data;
GO

CREATE TABLE bronze.transactions_data (
    id              VARCHAR(15),
    [date]          VARCHAR(25),
    client_id       VARCHAR(10),
    card_id         VARCHAR(10),
    amount          VARCHAR(20),
    use_chip        VARCHAR(30),
    merchant_id     VARCHAR(10),
    merchant_city   VARCHAR(50),
    merchant_state  VARCHAR(50),
    zip             VARCHAR(10),
    mcc             VARCHAR(10),
    errors          VARCHAR(100)
);
GO

-------------------------------------------------------------------------------
-- mcc_codes.json : 109 rows, merchant category code -> description
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS bronze.mcc_codes;
GO

CREATE TABLE bronze.mcc_codes (
    mcc          VARCHAR(10),
    description  VARCHAR(100)
);
GO

-------------------------------------------------------------------------------
-- train_fraud_labels.json : 8,914,963 rows, transaction id -> 'Yes' / 'No'
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS bronze.train_fraud_labels;
GO

CREATE TABLE bronze.train_fraud_labels (
    transaction_id  VARCHAR(15),
    is_fraud        VARCHAR(10)
);
GO

-- #############################################################################
-- FILE: scripts/bronze/proc_load_bronze.sql
-- #############################################################################
/*
===============================================================================
 Stored Procedure: Load Bronze Layer (Source files -> Bronze)
===============================================================================
 Purpose:
   Full load of the 5 source files into the bronze tables.
   For each table it truncates the table, loads the file as-is, then prints
   the row count and how long it took.
     - CSV files  : BULK INSERT
     - JSON files : OPENROWSET(BULK ...) + OPENJSON

 Parameter:
   @data_path : folder that has the 5 source files.
                Default = C:\DWH\datasets\

 Usage:
   EXEC bronze.load_bronze;
   EXEC bronze.load_bronze @data_path = N'D:\data\finance\';

 Source file notes (checked on the raw files):
   - users_data.csv, transactions_data.csv : lines end with LF   -> ROWTERMINATOR = '0x0a'
   - cards_data.csv                        : lines end with CRLF -> ROWTERMINATOR = '\r\n'
     (with '0x0a' a hidden CR char would stay at the end of the last column)
   - 941 transactions have more than one error inside quotes,
     for example "Bad PIN,Insufficient Balance".
     FORMAT = 'CSV' reads quoted values correctly (needs SQL Server 2017 or newer).
===============================================================================
*/

USE FinanceDWH;
GO

CREATE OR ALTER PROCEDURE bronze.load_bronze
    @data_path NVARCHAR(260) = N'C:\DWH\datasets\'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @path        NVARCHAR(260),
            @sql         NVARCHAR(MAX),
            @row_count   BIGINT,
            @start_time  DATETIME2(0),
            @batch_start DATETIME2(0) = SYSDATETIME();

    -- The folder must end with '\'.
    -- Single quotes are doubled because the path goes inside dynamic SQL.
    SET @path = @data_path + CASE WHEN RIGHT(@data_path, 1) = N'\' THEN N'' ELSE N'\' END;
    SET @path = REPLACE(@path, N'''', N'''''');

    BEGIN TRY
        PRINT '===============================================';
        PRINT 'Loading Bronze Layer from: ' + @data_path;
        PRINT '===============================================';

        -----------------------------------------------------------------------
        -- 1) users_data.csv  (lines end with LF)
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE bronze.users_data;

        SET @sql = N'
            BULK INSERT bronze.users_data
            FROM ''' + @path + N'users_data.csv''
            WITH (
                FORMAT          = ''CSV'',
                FIRSTROW        = 2,
                FIELDTERMINATOR = '','',
                FIELDQUOTE      = ''"'',
                ROWTERMINATOR   = ''0x0a'',
                TABLOCK
            );';
        EXEC sp_executesql @sql;

        SELECT @row_count = COUNT_BIG(*) FROM bronze.users_data;
        PRINT '>> bronze.users_data         : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 2) cards_data.csv  (lines end with CRLF)
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE bronze.cards_data;

        SET @sql = N'
            BULK INSERT bronze.cards_data
            FROM ''' + @path + N'cards_data.csv''
            WITH (
                FORMAT          = ''CSV'',
                FIRSTROW        = 2,
                FIELDTERMINATOR = '','',
                FIELDQUOTE      = ''"'',
                ROWTERMINATOR   = ''\r\n'',
                TABLOCK
            );';
        EXEC sp_executesql @sql;

        SELECT @row_count = COUNT_BIG(*) FROM bronze.cards_data;
        PRINT '>> bronze.cards_data         : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 3) transactions_data.csv  (lines end with LF, 1.26 GB)
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE bronze.transactions_data;

        SET @sql = N'
            BULK INSERT bronze.transactions_data
            FROM ''' + @path + N'transactions_data.csv''
            WITH (
                FORMAT          = ''CSV'',
                FIRSTROW        = 2,
                FIELDTERMINATOR = '','',
                FIELDQUOTE      = ''"'',
                ROWTERMINATOR   = ''0x0a'',
                TABLOCK
            );';
        EXEC sp_executesql @sql;

        SELECT @row_count = COUNT_BIG(*) FROM bronze.transactions_data;
        PRINT '>> bronze.transactions_data  : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 4) mcc_codes.json  ->  {"5812": "Eating Places and Restaurants", ...}
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE bronze.mcc_codes;

        SET @sql = N'
            INSERT INTO bronze.mcc_codes (mcc, description)
            SELECT j.[key], j.[value]
            FROM OPENROWSET(BULK ''' + @path + N'mcc_codes.json'', SINGLE_CLOB) AS f
            CROSS APPLY OPENJSON(f.BulkColumn) AS j;';
        EXEC sp_executesql @sql;

        SELECT @row_count = COUNT_BIG(*) FROM bronze.mcc_codes;
        PRINT '>> bronze.mcc_codes          : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 5) train_fraud_labels.json  ->  {"target": {"10649266": "No", ...}}
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE bronze.train_fraud_labels;

        SET @sql = N'
            INSERT INTO bronze.train_fraud_labels WITH (TABLOCK) (transaction_id, is_fraud)
            SELECT j.[key], j.[value]
            FROM OPENROWSET(BULK ''' + @path + N'train_fraud_labels.json'', SINGLE_CLOB) AS f
            CROSS APPLY OPENJSON(f.BulkColumn, ''$.target'') AS j;';
        EXEC sp_executesql @sql;

        SELECT @row_count = COUNT_BIG(*) FROM bronze.train_fraud_labels;
        PRINT '>> bronze.train_fraud_labels : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        PRINT '===============================================';
        PRINT 'Bronze Layer loaded in '
              + CAST(DATEDIFF(SECOND, @batch_start, SYSDATETIME()) AS VARCHAR(20)) + ' sec';
        PRINT '===============================================';
    END TRY
    BEGIN CATCH
        PRINT '===============================================';
        PRINT 'ERROR while loading the Bronze Layer';
        PRINT 'Message : ' + ERROR_MESSAGE();
        PRINT 'Number  : ' + CAST(ERROR_NUMBER() AS VARCHAR(20));
        PRINT '===============================================';
        THROW;
    END CATCH
END;
GO

-- #############################################################################
-- FILE: scripts/silver/ddl_silver.sql
-- #############################################################################
/*
===============================================================================
 DDL Script: Create Silver Tables
===============================================================================
 Purpose:
   Creates the silver tables. Silver holds cleaned and typed data:
     - real data types (INT, DECIMAL, DATE, BIT) instead of text
     - '$' signs removed, ZIP codes fixed, flags added
     - sensitive card data (card_number, cvv) is not carried over
     - multi-value errors are split into silver.transaction_errors

 Warning:
   Re-running this script drops and re-creates the silver tables.
   Reload them after that with: EXEC silver.load_silver;
===============================================================================
*/

USE FinanceDWH;
GO

-------------------------------------------------------------------------------
-- silver.users  (source: bronze.users_data)
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.users;
GO

CREATE TABLE silver.users (
    customer_id        INT            NOT NULL,
    current_age        TINYINT,
    retirement_age     TINYINT,
    birth_year         SMALLINT,
    birth_month        TINYINT,
    gender             VARCHAR(10),
    address            VARCHAR(100),
    latitude           DECIMAL(8,4),
    longitude          DECIMAL(8,4),
    per_capita_income  DECIMAL(12,2),   -- 0 in the source means unknown -> NULL
    yearly_income      DECIMAL(12,2),
    total_debt         DECIMAL(12,2),
    credit_score       SMALLINT,
    num_credit_cards   TINYINT,
    dwh_create_date    DATETIME2(0)   DEFAULT SYSDATETIME()
);
GO

-------------------------------------------------------------------------------
-- silver.cards  (source: bronze.cards_data)
-- Not carried over: card_number and cvv (sensitive), card_on_dark_web
-- (same value 'No' for every card).
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.cards;
GO

CREATE TABLE silver.cards (
    card_id                INT           NOT NULL,
    customer_id            INT,
    card_brand             VARCHAR(20),
    card_type              VARCHAR(20),
    has_chip               BIT,
    num_cards_issued       TINYINT,
    credit_limit           DECIMAL(12,2),
    expires_date           DATE,          -- last day of the expiry month
    acct_open_date         DATE,          -- first day of the opening month
    year_pin_last_changed  SMALLINT,
    dwh_create_date        DATETIME2(0)  DEFAULT SYSDATETIME()
);
GO

-------------------------------------------------------------------------------
-- silver.transactions  (source: bronze.transactions_data)
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.transactions;
GO

CREATE TABLE silver.transactions (
    transaction_id        INT           NOT NULL,
    transaction_datetime  DATETIME2(0),
    transaction_date      DATE,
    customer_id           INT,
    card_id               INT,
    amount                DECIMAL(12,2),
    is_refund             BIT,           -- 1 when amount < 0
    channel               VARCHAR(10),   -- Swipe / Chip / Online
    merchant_id           INT,
    is_online             BIT,           -- 1 when merchant_city = 'ONLINE'
    location_type         VARCHAR(15),   -- Online / United States / International
    merchant_city         VARCHAR(50),
    merchant_state        CHAR(2),       -- US state code only
    merchant_zip          CHAR(5),       -- 5 digits with leading zeros
    merchant_country      VARCHAR(50),   -- NULL for online merchants
    mcc                   SMALLINT,
    errors                VARCHAR(100),  -- NULL = no error
    has_error             BIT,
    dwh_create_date       DATETIME2(0)  DEFAULT SYSDATETIME()
);
GO

-------------------------------------------------------------------------------
-- silver.mcc_codes  (source: bronze.mcc_codes)
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.mcc_codes;
GO

CREATE TABLE silver.mcc_codes (
    mcc              SMALLINT      NOT NULL,
    description      VARCHAR(100),
    dwh_create_date  DATETIME2(0)  DEFAULT SYSDATETIME()
);
GO

-------------------------------------------------------------------------------
-- silver.fraud_labels  (source: bronze.train_fraud_labels)
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.fraud_labels;
GO

CREATE TABLE silver.fraud_labels (
    transaction_id   INT           NOT NULL,
    is_fraud         BIT,
    dwh_create_date  DATETIME2(0)  DEFAULT SYSDATETIME()
);
GO

-------------------------------------------------------------------------------
-- silver.transaction_errors  (one row per transaction per error)
-- Built from silver.transactions.errors, e.g. 'Bad PIN,Insufficient Balance'
-- becomes 2 rows.
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS silver.transaction_errors;
GO

CREATE TABLE silver.transaction_errors (
    transaction_id   INT           NOT NULL,
    error_type       VARCHAR(50)   NOT NULL,
    dwh_create_date  DATETIME2(0)  DEFAULT SYSDATETIME()
);
GO

-- #############################################################################
-- FILE: scripts/silver/proc_load_silver.sql
-- #############################################################################
/*
===============================================================================
 Stored Procedure: Load Silver Layer (Bronze -> Silver)
===============================================================================
 Purpose:
   Full load of the silver tables from bronze. For each table it truncates
   the table, inserts cleaned rows, then prints the row count and the time.

 Cleaning rules (see docs/bronze_notes.md for the numbers):
   users         : text -> numbers, '$' removed, per_capita_income 0 -> NULL
   cards         : 'YES'/'NO' -> BIT, 'MM/YYYY' -> DATE, '$' removed,
                   card_number / cvv / card_on_dark_web dropped
   transactions  : '$' removed, is_refund flag (amount < 0),
                   'Swipe Transaction' -> 'Swipe' (same for Chip / Online),
                   'ONLINE' city -> is_online flag + location_type,
                   merchant_state split into state (US code) and country,
                   ZIP '2860.0' -> '02860', empty errors -> NULL + has_error flag
   mcc_codes     : code -> SMALLINT
   fraud_labels  : 'Yes'/'No' -> BIT
   transaction_errors : one row per error ('Bad PIN,Insufficient Balance' -> 2 rows)

 Usage:
   EXEC silver.load_silver;
===============================================================================
*/

USE FinanceDWH;
GO

CREATE OR ALTER PROCEDURE silver.load_silver
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @row_count   BIGINT,
            @start_time  DATETIME2(0),
            @batch_start DATETIME2(0) = SYSDATETIME();

    BEGIN TRY
        PRINT '===============================================';
        PRINT 'Loading Silver Layer';
        PRINT '===============================================';

        -----------------------------------------------------------------------
        -- 1) silver.users
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.users;

        INSERT INTO silver.users WITH (TABLOCK) (
            customer_id, current_age, retirement_age, birth_year, birth_month,
            gender, address, latitude, longitude,
            per_capita_income, yearly_income, total_debt,
            credit_score, num_credit_cards
        )
        SELECT
            TRY_CAST(TRIM(id)             AS INT),
            TRY_CAST(TRIM(current_age)    AS TINYINT),
            TRY_CAST(TRIM(retirement_age) AS TINYINT),
            TRY_CAST(TRIM(birth_year)     AS SMALLINT),
            TRY_CAST(TRIM(birth_month)    AS TINYINT),
            TRIM(gender),
            TRIM(address),
            TRY_CAST(TRIM(latitude)       AS DECIMAL(8,4)),
            TRY_CAST(TRIM(longitude)      AS DECIMAL(8,4)),
            NULLIF(TRY_CAST(REPLACE(TRIM(per_capita_income), '$', '') AS DECIMAL(12,2)), 0),
            TRY_CAST(REPLACE(TRIM(yearly_income), '$', '') AS DECIMAL(12,2)),
            TRY_CAST(REPLACE(TRIM(total_debt),    '$', '') AS DECIMAL(12,2)),
            TRY_CAST(TRIM(credit_score)     AS SMALLINT),
            TRY_CAST(TRIM(num_credit_cards) AS TINYINT)
        FROM bronze.users_data;

        SELECT @row_count = COUNT_BIG(*) FROM silver.users;
        PRINT '>> silver.users              : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 2) silver.cards
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.cards;

        INSERT INTO silver.cards WITH (TABLOCK) (
            card_id, customer_id, card_brand, card_type, has_chip,
            num_cards_issued, credit_limit, expires_date, acct_open_date,
            year_pin_last_changed
        )
        SELECT
            TRY_CAST(TRIM(id)        AS INT),
            TRY_CAST(TRIM(client_id) AS INT),
            TRIM(card_brand),
            TRIM(card_type),
            CASE UPPER(TRIM(has_chip)) WHEN 'YES' THEN 1 WHEN 'NO' THEN 0 END,
            TRY_CAST(TRIM(num_cards_issued) AS TINYINT),
            TRY_CAST(REPLACE(TRIM(credit_limit), '$', '') AS DECIMAL(12,2)),
            -- 'MM/YYYY' -> last day of that month
            EOMONTH(DATEFROMPARTS(TRY_CAST(RIGHT(TRIM(expires), 4) AS INT),
                                  TRY_CAST(LEFT(TRIM(expires), 2)  AS INT), 1)),
            -- 'MM/YYYY' -> first day of that month
            DATEFROMPARTS(TRY_CAST(RIGHT(TRIM(acct_open_date), 4) AS INT),
                          TRY_CAST(LEFT(TRIM(acct_open_date), 2)  AS INT), 1),
            TRY_CAST(TRIM(year_pin_last_changed) AS SMALLINT)
        FROM bronze.cards_data;

        SELECT @row_count = COUNT_BIG(*) FROM silver.cards;
        PRINT '>> silver.cards              : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 3) silver.transactions  (13.3M rows)
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.transactions;

        INSERT INTO silver.transactions WITH (TABLOCK) (
            transaction_id, transaction_datetime, transaction_date,
            customer_id, card_id, amount, is_refund, channel, merchant_id,
            is_online, location_type, merchant_city, merchant_state, merchant_zip,
            merchant_country, mcc, errors, has_error
        )
        SELECT
            TRY_CAST(TRIM(t.id) AS INT),
            v.tx_datetime,
            CAST(v.tx_datetime AS DATE),
            TRY_CAST(TRIM(t.client_id) AS INT),
            TRY_CAST(TRIM(t.card_id)   AS INT),
            v.amount,
            CASE WHEN v.amount < 0 THEN 1 ELSE 0 END,
            CASE TRIM(t.use_chip)
                WHEN 'Swipe Transaction'  THEN 'Swipe'
                WHEN 'Chip Transaction'   THEN 'Chip'
                WHEN 'Online Transaction' THEN 'Online'
                ELSE 'Unknown'
            END,
            TRY_CAST(TRIM(t.merchant_id) AS INT),
            v.is_online,
            CASE
                WHEN v.is_online = 1                 THEN 'Online'
                WHEN LEN(TRIM(t.merchant_state)) = 2 THEN 'United States'
                ELSE 'International'
            END,
            CASE WHEN v.is_online = 1 THEN 'Online' ELSE TRIM(t.merchant_city) END,
            -- the source column holds a US state code OR a country name
            CASE WHEN LEN(TRIM(t.merchant_state)) = 2 THEN TRIM(t.merchant_state) END,
            -- ZIP was stored like a decimal: '2860.0' -> '02860'
            CASE WHEN NULLIF(TRIM(t.zip), '') IS NOT NULL
                 THEN RIGHT('00000' + LEFT(TRIM(t.zip), CHARINDEX('.', TRIM(t.zip) + '.') - 1), 5)
            END,
            CASE
                WHEN v.is_online = 1                 THEN NULL
                WHEN LEN(TRIM(t.merchant_state)) = 2 THEN 'United States'
                ELSE TRIM(t.merchant_state)
            END,
            TRY_CAST(TRIM(t.mcc) AS SMALLINT),
            NULLIF(TRIM(t.errors), ''),
            CASE WHEN NULLIF(TRIM(t.errors), '') IS NULL THEN 0 ELSE 1 END
        FROM bronze.transactions_data AS t
        CROSS APPLY (
            SELECT
                TRY_CONVERT(DATETIME2(0), TRIM(t.[date]), 120)              AS tx_datetime,
                TRY_CAST(REPLACE(TRIM(t.amount), '$', '') AS DECIMAL(12,2)) AS amount,
                CASE WHEN UPPER(TRIM(t.merchant_city)) = 'ONLINE' THEN 1 ELSE 0 END AS is_online
        ) AS v;

        SELECT @row_count = COUNT_BIG(*) FROM silver.transactions;
        PRINT '>> silver.transactions       : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 4) silver.mcc_codes
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.mcc_codes;

        INSERT INTO silver.mcc_codes (mcc, description)
        SELECT
            TRY_CAST(TRIM(mcc) AS SMALLINT),
            TRIM(description)
        FROM bronze.mcc_codes;

        SELECT @row_count = COUNT_BIG(*) FROM silver.mcc_codes;
        PRINT '>> silver.mcc_codes          : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 5) silver.fraud_labels
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.fraud_labels;

        INSERT INTO silver.fraud_labels WITH (TABLOCK) (transaction_id, is_fraud)
        SELECT
            TRY_CAST(TRIM(transaction_id) AS INT),
            CASE TRIM(is_fraud) WHEN 'Yes' THEN 1 WHEN 'No' THEN 0 END
        FROM bronze.train_fraud_labels;

        SELECT @row_count = COUNT_BIG(*) FROM silver.fraud_labels;
        PRINT '>> silver.fraud_labels       : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 6) silver.transaction_errors  (split the multi-value errors)
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.transaction_errors;

        INSERT INTO silver.transaction_errors WITH (TABLOCK) (transaction_id, error_type)
        SELECT
            t.transaction_id,
            TRIM(s.value)
        FROM silver.transactions AS t
        CROSS APPLY STRING_SPLIT(t.errors, ',') AS s
        WHERE t.errors IS NOT NULL
          AND TRIM(s.value) <> '';

        SELECT @row_count = COUNT_BIG(*) FROM silver.transaction_errors;
        PRINT '>> silver.transaction_errors : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        PRINT '===============================================';
        PRINT 'Silver Layer loaded in '
              + CAST(DATEDIFF(SECOND, @batch_start, SYSDATETIME()) AS VARCHAR(20)) + ' sec';
        PRINT '===============================================';
    END TRY
    BEGIN CATCH
        PRINT '===============================================';
        PRINT 'ERROR while loading the Silver Layer';
        PRINT 'Message : ' + ERROR_MESSAGE();
        PRINT 'Number  : ' + CAST(ERROR_NUMBER() AS VARCHAR(20));
        PRINT '===============================================';
        THROW;
    END CATCH
END;
GO

-- #############################################################################
-- FILE: scripts/gold/ddl_gold.sql
-- #############################################################################
/*
===============================================================================
 DDL Script: Create Gold Tables (Star Schema)
===============================================================================
 Purpose:
   Creates the gold layer: a star schema ready for Power BI.

     Dimensions : dim_date, dim_customer, dim_card, dim_mcc,
                  dim_location, dim_channel
     Facts      : fact_transactions        (1 row per transaction)
                  fact_transaction_errors  (1 row per transaction per error)

   Both facts share the same dimensions, so one slicer filters both.

 Warning:
   Re-running this script drops and re-creates the gold tables.
   Reload them after that with: EXEC gold.load_gold;
===============================================================================
*/

USE FinanceDWH;
GO

DROP TABLE IF EXISTS gold.fact_transaction_errors;
DROP TABLE IF EXISTS gold.fact_transactions;
DROP TABLE IF EXISTS gold.dim_date;
DROP TABLE IF EXISTS gold.dim_customer;
DROP TABLE IF EXISTS gold.dim_card;
DROP TABLE IF EXISTS gold.dim_mcc;
DROP TABLE IF EXISTS gold.dim_location;
DROP TABLE IF EXISTS gold.dim_channel;
GO

-------------------------------------------------------------------------------
-- dim_date : one row per day for every year that has transactions
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_date (
    date_key        INT          NOT NULL,   -- yyyymmdd
    full_date       DATE         NOT NULL,
    year            SMALLINT     NOT NULL,
    quarter         TINYINT      NOT NULL,
    quarter_name    CHAR(2)      NOT NULL,   -- Q1 .. Q4
    month_number    TINYINT      NOT NULL,
    month_name      VARCHAR(10)  NOT NULL,
    month_short     CHAR(3)      NOT NULL,
    year_month      CHAR(7)      NOT NULL,   -- 2019-10
    year_month_key  INT          NOT NULL,   -- 201910 (sort helper)
    day_of_month    TINYINT      NOT NULL,
    day_of_week     TINYINT      NOT NULL,   -- 1 = Monday .. 7 = Sunday
    day_name        VARCHAR(10)  NOT NULL,
    day_short       CHAR(3)      NOT NULL,
    day_type        VARCHAR(7)   NOT NULL,   -- Weekday / Weekend
    CONSTRAINT pk_dim_date PRIMARY KEY (date_key)
);
GO

-------------------------------------------------------------------------------
-- dim_customer : one row per client (key = source client id)
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_customer (
    customer_key        INT            NOT NULL,
    gender              VARCHAR(10),
    current_age         TINYINT,
    age_group           VARCHAR(10),
    age_group_sort      TINYINT,
    birth_year          SMALLINT,
    retirement_age      TINYINT,
    yearly_income       DECIMAL(12,2),
    income_band         VARCHAR(10),
    income_band_sort    TINYINT,
    per_capita_income   DECIMAL(12,2),
    total_debt          DECIMAL(12,2),
    credit_score        SMALLINT,
    credit_band         VARCHAR(10),
    credit_band_sort    TINYINT,
    num_credit_cards    TINYINT,
    latitude            DECIMAL(8,4),
    longitude           DECIMAL(8,4),
    CONSTRAINT pk_dim_customer PRIMARY KEY (customer_key)
);
GO

-------------------------------------------------------------------------------
-- dim_card : one row per card (key = source card id)
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_card (
    card_key               INT            NOT NULL,
    customer_key           INT,
    card_brand             VARCHAR(20),
    card_type              VARCHAR(20),
    has_chip               VARCHAR(3),    -- Yes / No
    num_cards_issued       TINYINT,
    credit_limit           DECIMAL(12,2),
    acct_open_date         DATE,
    acct_open_year         SMALLINT,
    expires_date           DATE,
    year_pin_last_changed  SMALLINT,
    CONSTRAINT pk_dim_card PRIMARY KEY (card_key)
);
GO

-------------------------------------------------------------------------------
-- dim_mcc : merchant category (key = MCC code) + a broader category group
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_mcc (
    mcc_key          SMALLINT      NOT NULL,
    mcc_description  VARCHAR(100),
    mcc_category     VARCHAR(40),
    CONSTRAINT pk_dim_mcc PRIMARY KEY (mcc_key)
);
GO

-------------------------------------------------------------------------------
-- dim_location : where the merchant is (surrogate key)
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_location (
    location_key   INT IDENTITY(1,1) NOT NULL,
    location_type  VARCHAR(15)   NOT NULL,   -- Online / United States / International
    country        VARCHAR(50)   NOT NULL,   -- 'Online' for online merchants
    state          CHAR(2),                  -- US only
    city           VARCHAR(50)   NOT NULL,
    zip            CHAR(5),                  -- US only
    location_code  VARCHAR(150)  NOT NULL,   -- business key used by the fact load
    CONSTRAINT pk_dim_location PRIMARY KEY (location_key)
);
GO

-------------------------------------------------------------------------------
-- dim_channel : Swipe / Chip / Online
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_channel (
    channel_key   TINYINT      NOT NULL,
    channel_name  VARCHAR(10)  NOT NULL,
    CONSTRAINT pk_dim_channel PRIMARY KEY (channel_key)
);
GO

-------------------------------------------------------------------------------
-- fact_transactions : one row per transaction (13.3M rows)
-------------------------------------------------------------------------------
CREATE TABLE gold.fact_transactions (
    transaction_id    INT            NOT NULL,
    date_key          INT            NOT NULL,
    transaction_hour  TINYINT        NOT NULL,
    customer_key      INT            NOT NULL,
    card_key          INT            NOT NULL,
    location_key      INT            NOT NULL,
    mcc_key           SMALLINT       NOT NULL,
    channel_key       TINYINT        NOT NULL,
    merchant_id       INT            NOT NULL,
    amount            DECIMAL(12,2)  NOT NULL,
    is_refund         TINYINT        NOT NULL,   -- 1 = negative amount
    has_error         TINYINT        NOT NULL,   -- 1 = at least one error
    fraud_status      VARCHAR(10)    NOT NULL,   -- Fraud / Legit / Unlabeled
    is_fraud          TINYINT        NULL        -- 1 / 0 / NULL when no label
);
GO

-- Columnstore: smaller table and fast aggregations for Power BI
CREATE CLUSTERED COLUMNSTORE INDEX cci_fact_transactions ON gold.fact_transactions;
GO

-------------------------------------------------------------------------------
-- fact_transaction_errors : one row per transaction per error type
-------------------------------------------------------------------------------
CREATE TABLE gold.fact_transaction_errors (
    transaction_id  INT            NOT NULL,
    error_type      VARCHAR(50)    NOT NULL,
    date_key        INT            NOT NULL,
    customer_key    INT            NOT NULL,
    card_key        INT            NOT NULL,
    location_key    INT            NOT NULL,
    mcc_key         SMALLINT       NOT NULL,
    channel_key     TINYINT        NOT NULL,
    amount          DECIMAL(12,2)  NOT NULL
);
GO

-- #############################################################################
-- FILE: scripts/gold/proc_load_gold.sql
-- #############################################################################
/*
===============================================================================
 Stored Procedure: Load Gold Layer (Silver -> Gold star schema)
===============================================================================
 Purpose:
   Full load of the gold dimensions and facts from silver.
   For each table it truncates the table, inserts the rows, then prints the
   row count and the time it took. Dimensions load first, then facts.

 Usage:
   EXEC gold.load_gold;
===============================================================================
*/

USE FinanceDWH;
GO

CREATE OR ALTER PROCEDURE gold.load_gold
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @row_count   BIGINT,
            @start_time  DATETIME2(0),
            @batch_start DATETIME2(0) = SYSDATETIME(),
            @date_from   DATE,
            @date_to     DATE;

    BEGIN TRY
        PRINT '===============================================';
        PRINT 'Loading Gold Layer';
        PRINT '===============================================';

        -----------------------------------------------------------------------
        -- 1) dim_date : full years that cover all transactions
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_date;

        SELECT @date_from = DATEFROMPARTS(YEAR(MIN(transaction_date)), 1, 1),
               @date_to   = DATEFROMPARTS(YEAR(MAX(transaction_date)), 12, 31)
        FROM silver.transactions;

        WITH numbers AS (
            SELECT TOP (DATEDIFF(DAY, @date_from, @date_to) + 1)
                   ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS n
            FROM sys.all_objects AS a
            CROSS JOIN sys.all_objects AS b
        )
        INSERT INTO gold.dim_date (
            date_key, full_date, year, quarter, quarter_name,
            month_number, month_name, month_short, year_month, year_month_key,
            day_of_month, day_of_week, day_name, day_short, day_type
        )
        SELECT
            YEAR(d.full_date) * 10000 + MONTH(d.full_date) * 100 + DAY(d.full_date),
            d.full_date,
            YEAR(d.full_date),
            DATEPART(QUARTER, d.full_date),
            CONCAT('Q', DATEPART(QUARTER, d.full_date)),
            MONTH(d.full_date),
            CHOOSE(MONTH(d.full_date), 'January', 'February', 'March', 'April', 'May', 'June',
                   'July', 'August', 'September', 'October', 'November', 'December'),
            CHOOSE(MONTH(d.full_date), 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                   'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'),
            CONCAT(YEAR(d.full_date), '-', RIGHT(CONCAT('0', MONTH(d.full_date)), 2)),
            YEAR(d.full_date) * 100 + MONTH(d.full_date),
            DAY(d.full_date),
            w.dow,
            CHOOSE(w.dow, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
            CHOOSE(w.dow, 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'),
            CASE WHEN w.dow IN (6, 7) THEN 'Weekend' ELSE 'Weekday' END
        FROM numbers
        CROSS APPLY (SELECT DATEADD(DAY, numbers.n, @date_from) AS full_date) AS d
        -- 1900-01-01 was a Monday, so this gives 1 = Monday .. 7 = Sunday
        -- (it does not depend on the server's DATEFIRST setting)
        CROSS APPLY (SELECT DATEDIFF(DAY, '19000101', d.full_date) % 7 + 1 AS dow) AS w;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_date;
        PRINT '>> gold.dim_date                : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 2) dim_customer : with age group, income band, credit band
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_customer;

        INSERT INTO gold.dim_customer (
            customer_key, gender, current_age, age_group, age_group_sort,
            birth_year, retirement_age, yearly_income, income_band, income_band_sort,
            per_capita_income, total_debt, credit_score, credit_band, credit_band_sort,
            num_credit_cards, latitude, longitude
        )
        SELECT
            u.customer_id,
            u.gender,
            u.current_age,
            CHOOSE(b.age_sort, '18-24', '25-34', '35-44', '45-54', '55-64', '65+'),
            b.age_sort,
            u.birth_year,
            u.retirement_age,
            u.yearly_income,
            CHOOSE(b.income_sort, '<25K', '25K-50K', '50K-75K', '75K-100K', '100K+'),
            b.income_sort,
            u.per_capita_income,
            u.total_debt,
            u.credit_score,
            -- FICO score ranges
            CHOOSE(b.credit_sort, 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent'),
            b.credit_sort,
            u.num_credit_cards,
            u.latitude,
            u.longitude
        FROM silver.users AS u
        CROSS APPLY (
            SELECT
                CASE
                    WHEN u.current_age IS NULL THEN NULL
                    WHEN u.current_age < 25 THEN 1
                    WHEN u.current_age < 35 THEN 2
                    WHEN u.current_age < 45 THEN 3
                    WHEN u.current_age < 55 THEN 4
                    WHEN u.current_age < 65 THEN 5
                    ELSE 6
                END AS age_sort,
                CASE
                    WHEN u.yearly_income IS NULL THEN NULL
                    WHEN u.yearly_income < 25000  THEN 1
                    WHEN u.yearly_income < 50000  THEN 2
                    WHEN u.yearly_income < 75000  THEN 3
                    WHEN u.yearly_income < 100000 THEN 4
                    ELSE 5
                END AS income_sort,
                CASE
                    WHEN u.credit_score IS NULL THEN NULL
                    WHEN u.credit_score < 580 THEN 1
                    WHEN u.credit_score < 670 THEN 2
                    WHEN u.credit_score < 740 THEN 3
                    WHEN u.credit_score < 800 THEN 4
                    ELSE 5
                END AS credit_sort
        ) AS b;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_customer;
        PRINT '>> gold.dim_customer            : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 3) dim_card
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_card;

        INSERT INTO gold.dim_card (
            card_key, customer_key, card_brand, card_type, has_chip,
            num_cards_issued, credit_limit, acct_open_date, acct_open_year,
            expires_date, year_pin_last_changed
        )
        SELECT
            card_id,
            customer_id,
            card_brand,
            card_type,
            CASE has_chip WHEN 1 THEN 'Yes' WHEN 0 THEN 'No' END,
            num_cards_issued,
            credit_limit,
            acct_open_date,
            YEAR(acct_open_date),
            expires_date,
            year_pin_last_changed
        FROM silver.cards;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_card;
        PRINT '>> gold.dim_card                : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 4) dim_mcc : 109 codes grouped into 14 categories
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_mcc;

        INSERT INTO gold.dim_mcc (mcc_key, mcc_description, mcc_category)
        SELECT
            mcc,
            description,
            CASE
                WHEN mcc IN (5300, 5411, 5499, 5921)
                    THEN 'Groceries & Food Stores'
                WHEN mcc IN (5812, 5813, 5814)
                    THEN 'Restaurants & Bars'
                WHEN mcc IN (5533, 5541, 7531, 7538, 7542, 7549)
                    THEN 'Fuel & Automotive'
                WHEN mcc IN (3722, 3771, 3775, 4111, 4112, 4121, 4131, 4214, 4784)
                    THEN 'Transportation'
                WHEN mcc IN (4411, 4511, 4722, 7011)
                    THEN 'Travel & Lodging'
                WHEN mcc IN (3132, 5094, 5192, 5193, 5310, 5311, 5621, 5651, 5655,
                             5661, 5932, 5941, 5942, 5947, 5970, 5977)
                    THEN 'Retail Shopping'
                WHEN mcc IN (5045, 5732, 5733, 5815, 5816)
                    THEN 'Electronics & Digital'
                WHEN mcc IN (1711, 3144, 3174, 3256, 3260, 3504, 3640, 5211, 5251,
                             5261, 5712, 5719, 5722)
                    THEN 'Home & Garden'
                WHEN mcc IN (5912, 8011, 8021, 8041, 8043, 8049, 8062, 8099)
                    THEN 'Health & Medical'
                WHEN mcc IN (3780, 4814, 4899, 4900, 6300)
                    THEN 'Bills & Utilities'
                WHEN mcc IN (4829, 7276, 8111, 8931)
                    THEN 'Money & Professional'
                WHEN mcc IN (7801, 7802, 7832, 7922, 7995, 7996)
                    THEN 'Entertainment'
                WHEN mcc IN (7210, 7230, 7349, 7393, 9402)
                    THEN 'Personal Services'
                WHEN mcc IN (3000, 3001, 3005, 3006, 3007, 3008, 3009, 3058, 3066,
                             3075, 3359, 3387, 3389, 3390, 3393, 3395, 3405, 3509,
                             3596, 3684, 3730)
                    THEN 'Industrial & Manufacturing'
                ELSE 'Other'
            END
        FROM silver.mcc_codes;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_mcc;
        PRINT '>> gold.dim_mcc                 : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 5) dim_location : distinct merchant locations
        --    location_code must be built the same way in the fact load below
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_location;   -- also resets the IDENTITY

        INSERT INTO gold.dim_location (location_type, country, state, city, zip, location_code)
        SELECT
            x.location_type,
            x.country,
            x.state,
            x.city,
            x.zip,
            CONCAT(x.location_type, '|', x.country, '|', ISNULL(x.state, ''), '|',
                   x.city, '|', ISNULL(x.zip, ''))
        FROM (
            SELECT DISTINCT
                t.location_type,
                ISNULL(t.merchant_country, 'Online') AS country,
                t.merchant_state AS state,
                t.merchant_city  AS city,
                t.merchant_zip   AS zip
            FROM silver.transactions AS t
        ) AS x
        ORDER BY x.location_type, x.country, x.state, x.city, x.zip;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_location;
        PRINT '>> gold.dim_location            : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 6) dim_channel
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.dim_channel;

        INSERT INTO gold.dim_channel (channel_key, channel_name)
        SELECT DISTINCT
            CASE channel WHEN 'Swipe' THEN 1 WHEN 'Chip' THEN 2 WHEN 'Online' THEN 3 ELSE 9 END,
            channel
        FROM silver.transactions;

        SELECT @row_count = COUNT_BIG(*) FROM gold.dim_channel;
        PRINT '>> gold.dim_channel             : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 7) fact_transactions  (13.3M rows)
        --    LEFT JOIN on purpose: a missing location would hit the NOT NULL
        --    rule and stop the load, instead of silently dropping rows.
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.fact_transactions;

        INSERT INTO gold.fact_transactions WITH (TABLOCK) (
            transaction_id, date_key, transaction_hour, customer_key, card_key,
            location_key, mcc_key, channel_key, merchant_id, amount,
            is_refund, has_error, fraud_status, is_fraud
        )
        SELECT
            t.transaction_id,
            YEAR(t.transaction_date) * 10000 + MONTH(t.transaction_date) * 100 + DAY(t.transaction_date),
            DATEPART(HOUR, t.transaction_datetime),
            t.customer_id,
            t.card_id,
            l.location_key,
            t.mcc,
            CASE t.channel WHEN 'Swipe' THEN 1 WHEN 'Chip' THEN 2 WHEN 'Online' THEN 3 ELSE 9 END,
            t.merchant_id,
            t.amount,
            t.is_refund,
            t.has_error,
            CASE f.is_fraud WHEN 1 THEN 'Fraud' WHEN 0 THEN 'Legit' ELSE 'Unlabeled' END,
            f.is_fraud
        FROM silver.transactions AS t
        LEFT JOIN gold.dim_location AS l
            ON l.location_code = CONCAT(t.location_type, '|', ISNULL(t.merchant_country, 'Online'), '|',
                                        ISNULL(t.merchant_state, ''), '|', t.merchant_city, '|',
                                        ISNULL(t.merchant_zip, ''))
        LEFT JOIN silver.fraud_labels AS f
            ON f.transaction_id = t.transaction_id;

        SELECT @row_count = COUNT_BIG(*) FROM gold.fact_transactions;
        PRINT '>> gold.fact_transactions       : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 8) fact_transaction_errors : same keys as the transaction
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE gold.fact_transaction_errors;

        INSERT INTO gold.fact_transaction_errors WITH (TABLOCK) (
            transaction_id, error_type, date_key, customer_key, card_key,
            location_key, mcc_key, channel_key, amount
        )
        SELECT
            e.transaction_id,
            e.error_type,
            f.date_key,
            f.customer_key,
            f.card_key,
            f.location_key,
            f.mcc_key,
            f.channel_key,
            f.amount
        FROM silver.transaction_errors AS e
        JOIN gold.fact_transactions AS f
            ON f.transaction_id = e.transaction_id;

        SELECT @row_count = COUNT_BIG(*) FROM gold.fact_transaction_errors;
        PRINT '>> gold.fact_transaction_errors : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        PRINT '===============================================';
        PRINT 'Gold Layer loaded in '
              + CAST(DATEDIFF(SECOND, @batch_start, SYSDATETIME()) AS VARCHAR(20)) + ' sec';
        PRINT '===============================================';
    END TRY
    BEGIN CATCH
        PRINT '===============================================';
        PRINT 'ERROR while loading the Gold Layer';
        PRINT 'Message : ' + ERROR_MESSAGE();
        PRINT 'Number  : ' + CAST(ERROR_NUMBER() AS VARCHAR(20));
        PRINT '===============================================';
        THROW;
    END CATCH
END;
GO

-- #############################################################################
-- RUN THE ETL (stops at the first error)
-- #############################################################################
USE FinanceDWH;
GO

BEGIN TRY
    EXEC bronze.load_bronze @data_path = N'C:\DWH\datasets\';
    EXEC silver.load_silver;
    EXEC gold.load_gold;
END TRY
BEGIN CATCH
    PRINT 'BUILD STOPPED: ' + ERROR_MESSAGE();
    THROW;
END CATCH;
GO

-- #############################################################################
-- FILE: tests/quality_checks_bronze.sql
-- #############################################################################
/*
===============================================================================
 Quality Checks: Bronze Layer
===============================================================================
 Run after: EXEC bronze.load_bronze;
 Every row should show result = 'OK'.
 The expected numbers were counted directly from the raw source files.
===============================================================================
*/

USE FinanceDWH;
GO

SELECT check_id,
       check_name,
       expected,
       actual,
       CASE WHEN expected = actual THEN 'OK' ELSE 'CHECK' END AS result
FROM (
    -- Row counts: every data row of each file is loaded (header row skipped)
    SELECT 1 AS check_id,
           'users_data: row count' AS check_name,
           CAST(2000 AS BIGINT) AS expected,
           (SELECT COUNT_BIG(*) FROM bronze.users_data) AS actual
    UNION ALL
    SELECT 2, 'cards_data: row count', 6146,
           (SELECT COUNT_BIG(*) FROM bronze.cards_data)
    UNION ALL
    SELECT 3, 'transactions_data: row count', 13305915,
           (SELECT COUNT_BIG(*) FROM bronze.transactions_data)
    UNION ALL
    SELECT 4, 'mcc_codes: row count', 109,
           (SELECT COUNT_BIG(*) FROM bronze.mcc_codes)
    UNION ALL
    SELECT 5, 'train_fraud_labels: row count', 8914963,
           (SELECT COUNT_BIG(*) FROM bronze.train_fraud_labels)

    -- Parsing: the file formats were read correctly
    UNION ALL
    SELECT 6, 'train_fraud_labels: is_fraud = Yes', 13332,
           (SELECT COUNT_BIG(*) FROM bronze.train_fraud_labels WHERE is_fraud = 'Yes')
    UNION ALL
    SELECT 7, 'cards_data: hidden CR left at line end', 0,
           (SELECT COUNT_BIG(*) FROM bronze.cards_data WHERE card_on_dark_web LIKE '%' + CHAR(13) + '%')
    UNION ALL
    SELECT 8, 'transactions_data: amount starts with $ (columns in place)', 13305915,
           (SELECT COUNT_BIG(*) FROM bronze.transactions_data WHERE amount LIKE '$%')
    UNION ALL
    SELECT 9, 'transactions_data: quoted multi-errors kept as one value', 941,
           (SELECT COUNT_BIG(*) FROM bronze.transactions_data WHERE errors LIKE '%,%')
    UNION ALL
    SELECT 10, 'transactions_data: quote chars left in errors', 0,
           (SELECT COUNT_BIG(*) FROM bronze.transactions_data WHERE errors LIKE '%"%')
) AS c
ORDER BY check_id;
GO

-- #############################################################################
-- FILE: tests/quality_checks_silver.sql
-- #############################################################################
/*
===============================================================================
 Quality Checks: Silver Layer
===============================================================================
 Run after: EXEC silver.load_silver;
 Every row should show result = 'OK'.
 Expected numbers were counted from the raw files with the same rules.
===============================================================================
*/

USE FinanceDWH;
GO

SELECT check_id,
       check_name,
       expected,
       actual,
       CASE WHEN expected = actual THEN 'OK' ELSE 'CHECK' END AS result
FROM (
    ---------------------------------------------------------------------------
    -- Row counts
    ---------------------------------------------------------------------------
    SELECT 1 AS check_id, 'users: row count' AS check_name,
           CAST(2000 AS BIGINT) AS expected,
           (SELECT COUNT_BIG(*) FROM silver.users) AS actual
    UNION ALL
    SELECT 2, 'cards: row count', 6146,
           (SELECT COUNT_BIG(*) FROM silver.cards)
    UNION ALL
    SELECT 3, 'transactions: row count', 13305915,
           (SELECT COUNT_BIG(*) FROM silver.transactions)
    UNION ALL
    SELECT 4, 'mcc_codes: row count', 109,
           (SELECT COUNT_BIG(*) FROM silver.mcc_codes)
    UNION ALL
    SELECT 5, 'fraud_labels: row count', 8914963,
           (SELECT COUNT_BIG(*) FROM silver.fraud_labels)
    UNION ALL
    SELECT 6, 'transaction_errors: row count (one per error)', 212335,
           (SELECT COUNT_BIG(*) FROM silver.transaction_errors)

    ---------------------------------------------------------------------------
    -- Duplicates
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 7, 'users: duplicate customer_id', 0,
           (SELECT COUNT_BIG(*) - COUNT_BIG(DISTINCT customer_id) FROM silver.users)
    UNION ALL
    SELECT 8, 'cards: duplicate card_id', 0,
           (SELECT COUNT_BIG(*) - COUNT_BIG(DISTINCT card_id) FROM silver.cards)
    UNION ALL
    SELECT 9, 'transactions: duplicate transaction_id', 0,
           (SELECT COUNT_BIG(*) - COUNT_BIG(DISTINCT transaction_id) FROM silver.transactions)

    ---------------------------------------------------------------------------
    -- NULLs after type conversion (a failed TRY_CAST becomes NULL)
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 10, 'users: NULL in converted columns', 0,
           (SELECT COUNT_BIG(*) FROM silver.users
            WHERE current_age IS NULL OR yearly_income IS NULL OR total_debt IS NULL
               OR credit_score IS NULL OR latitude IS NULL OR longitude IS NULL)
    UNION ALL
    SELECT 11, 'users: per_capita_income NULL (was 0 in source)', 15,
           (SELECT COUNT_BIG(*) FROM silver.users WHERE per_capita_income IS NULL)
    UNION ALL
    SELECT 12, 'cards: NULL in converted columns', 0,
           (SELECT COUNT_BIG(*) FROM silver.cards
            WHERE customer_id IS NULL OR has_chip IS NULL OR credit_limit IS NULL
               OR expires_date IS NULL OR acct_open_date IS NULL)
    UNION ALL
    SELECT 13, 'transactions: NULL in converted columns', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions
            WHERE transaction_datetime IS NULL OR amount IS NULL OR customer_id IS NULL
               OR card_id IS NULL OR merchant_id IS NULL OR mcc IS NULL)

    ---------------------------------------------------------------------------
    -- Business rules
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 14, 'transactions: total amount in cents', 57183552228,
           (SELECT CAST(SUM(amount) * 100 AS BIGINT) FROM silver.transactions)
    UNION ALL
    SELECT 15, 'transactions: refunds (amount < 0)', 660049,
           (SELECT COUNT_BIG(*) FROM silver.transactions WHERE is_refund = 1)
    UNION ALL
    SELECT 16, 'transactions: online', 1563700,
           (SELECT COUNT_BIG(*) FROM silver.transactions WHERE location_type = 'Online')
    UNION ALL
    SELECT 17, 'transactions: international', 89006,
           (SELECT COUNT_BIG(*) FROM silver.transactions WHERE location_type = 'International')
    UNION ALL
    SELECT 18, 'transactions: US rows without state or 5-digit ZIP', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions
            WHERE location_type = 'United States'
              AND (merchant_state IS NULL OR merchant_zip IS NULL OR merchant_zip LIKE '%[^0-9]%'))
    UNION ALL
    SELECT 19, 'transactions: with at least one error', 211393,
           (SELECT COUNT_BIG(*) FROM silver.transactions WHERE has_error = 1)
    UNION ALL
    SELECT 20, 'transactions: unknown channel', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions WHERE channel = 'Unknown')
    UNION ALL
    SELECT 21, 'fraud_labels: is_fraud = 1', 13332,
           (SELECT COUNT_BIG(*) FROM silver.fraud_labels WHERE is_fraud = 1)

    ---------------------------------------------------------------------------
    -- Relationships between tables
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 22, 'transactions: customer not in users', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions AS t
            WHERE NOT EXISTS (SELECT 1 FROM silver.users AS u WHERE u.customer_id = t.customer_id))
    UNION ALL
    SELECT 23, 'transactions: card not in cards', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions AS t
            WHERE NOT EXISTS (SELECT 1 FROM silver.cards AS c WHERE c.card_id = t.card_id))
    UNION ALL
    SELECT 24, 'transactions: card owner <> transaction customer', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions AS t
            JOIN silver.cards AS c ON c.card_id = t.card_id
            WHERE c.customer_id <> t.customer_id)
    UNION ALL
    SELECT 25, 'transactions: mcc not in mcc_codes', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions AS t
            WHERE NOT EXISTS (SELECT 1 FROM silver.mcc_codes AS m WHERE m.mcc = t.mcc))
    UNION ALL
    SELECT 26, 'fraud_labels: transaction not found', 0,
           (SELECT COUNT_BIG(*) FROM silver.fraud_labels AS f
            WHERE NOT EXISTS (SELECT 1 FROM silver.transactions AS t WHERE t.transaction_id = f.transaction_id))
) AS c
ORDER BY check_id;
GO

-- #############################################################################
-- FILE: tests/quality_checks_gold.sql
-- #############################################################################
/*
===============================================================================
 Quality Checks: Gold Layer
===============================================================================
 Run after: EXEC gold.load_gold;
 Every row should show result = 'OK'.
 Expected numbers were counted from the raw files with the same rules.
===============================================================================
*/

USE FinanceDWH;
GO

SELECT check_id,
       check_name,
       expected,
       actual,
       CASE WHEN expected = actual THEN 'OK' ELSE 'CHECK' END AS result
FROM (
    ---------------------------------------------------------------------------
    -- Row counts
    ---------------------------------------------------------------------------
    SELECT 1 AS check_id, 'dim_date: row count (2010-2019)' AS check_name,
           CAST(3652 AS BIGINT) AS expected,
           (SELECT COUNT_BIG(*) FROM gold.dim_date) AS actual
    UNION ALL
    SELECT 2, 'dim_customer: row count', 2000,
           (SELECT COUNT_BIG(*) FROM gold.dim_customer)
    UNION ALL
    SELECT 3, 'dim_card: row count', 6146,
           (SELECT COUNT_BIG(*) FROM gold.dim_card)
    UNION ALL
    SELECT 4, 'dim_mcc: row count', 109,
           (SELECT COUNT_BIG(*) FROM gold.dim_mcc)
    UNION ALL
    SELECT 5, 'dim_mcc: codes without a category', 0,
           (SELECT COUNT_BIG(*) FROM gold.dim_mcc WHERE mcc_category = 'Other')
    UNION ALL
    SELECT 6, 'dim_location: row count', 25425,
           (SELECT COUNT_BIG(*) FROM gold.dim_location)
    UNION ALL
    SELECT 7, 'dim_channel: row count', 3,
           (SELECT COUNT_BIG(*) FROM gold.dim_channel)
    UNION ALL
    SELECT 8, 'fact_transactions: row count', 13305915,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions)
    UNION ALL
    SELECT 9, 'fact_transaction_errors: row count', 212335,
           (SELECT COUNT_BIG(*) FROM gold.fact_transaction_errors)

    ---------------------------------------------------------------------------
    -- Every fact key exists in its dimension
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 10, 'fact: date_key not in dim_date', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_date AS d WHERE d.date_key = f.date_key))
    UNION ALL
    SELECT 11, 'fact: customer_key not in dim_customer', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_customer AS d WHERE d.customer_key = f.customer_key))
    UNION ALL
    SELECT 12, 'fact: card_key not in dim_card', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_card AS d WHERE d.card_key = f.card_key))
    UNION ALL
    SELECT 13, 'fact: location_key not in dim_location', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_location AS d WHERE d.location_key = f.location_key))
    UNION ALL
    SELECT 14, 'fact: mcc_key not in dim_mcc', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_mcc AS d WHERE d.mcc_key = f.mcc_key))
    UNION ALL
    SELECT 15, 'fact: channel_key not in dim_channel', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions AS f
            WHERE NOT EXISTS (SELECT 1 FROM gold.dim_channel AS d WHERE d.channel_key = f.channel_key))
    UNION ALL
    SELECT 16, 'errors fact: transaction not in fact_transactions', 0,
           (SELECT COUNT_BIG(*) FROM gold.fact_transaction_errors AS e
            WHERE NOT EXISTS (SELECT 1 FROM gold.fact_transactions AS f WHERE f.transaction_id = e.transaction_id))

    ---------------------------------------------------------------------------
    -- Business numbers (match the source files)
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 17, 'fact: total amount in cents', 57183552228,
           (SELECT CAST(SUM(amount) * 100 AS BIGINT) FROM gold.fact_transactions)
    UNION ALL
    SELECT 18, 'fact: refund transactions', 660049,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions WHERE is_refund = 1)
    UNION ALL
    SELECT 19, 'fact: transactions with errors', 211393,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions WHERE has_error = 1)
    UNION ALL
    SELECT 20, 'fact: fraud_status = Fraud', 13332,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions WHERE fraud_status = 'Fraud')
    UNION ALL
    SELECT 21, 'fact: fraud_status = Legit', 8901631,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions WHERE fraud_status = 'Legit')
    UNION ALL
    SELECT 22, 'fact: fraud_status = Unlabeled', 4390952,
           (SELECT COUNT_BIG(*) FROM gold.fact_transactions WHERE fraud_status = 'Unlabeled')
) AS c
ORDER BY check_id;
GO
