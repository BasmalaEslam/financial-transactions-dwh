/*
===============================================================================
 DDL Script: Create Gold Tables (Star Schema)
===============================================================================
 Purpose:
   Creates the gold layer: a star schema ready for Power BI.

     Dimensions : dim_date, dim_customer, dim_card, dim_mcc,
                  dim_location, dim_channel
     Facts      : fact_transactions        (1 row per transaction)
                  fact_transaction_errors  (1 row per transaction per error)

   Both facts share the same dimensions, so one slicer filters both.

 Warning:
   Re-running this script drops and re-creates the gold tables.
   Reload them after that with: EXEC gold.load_gold;
===============================================================================
*/

USE FinanceDWH;
GO

DROP TABLE IF EXISTS gold.fact_transaction_errors;
DROP TABLE IF EXISTS gold.fact_transactions;
DROP TABLE IF EXISTS gold.dim_date;
DROP TABLE IF EXISTS gold.dim_customer;
DROP TABLE IF EXISTS gold.dim_card;
DROP TABLE IF EXISTS gold.dim_mcc;
DROP TABLE IF EXISTS gold.dim_location;
DROP TABLE IF EXISTS gold.dim_channel;
GO

-------------------------------------------------------------------------------
-- dim_date : one row per day for every year that has transactions
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_date (
    date_key        INT          NOT NULL,   -- yyyymmdd
    full_date       DATE         NOT NULL,
    year            SMALLINT     NOT NULL,
    quarter         TINYINT      NOT NULL,
    quarter_name    CHAR(2)      NOT NULL,   -- Q1 .. Q4
    month_number    TINYINT      NOT NULL,
    month_name      VARCHAR(10)  NOT NULL,
    month_short     CHAR(3)      NOT NULL,
    year_month      CHAR(7)      NOT NULL,   -- 2019-10
    year_month_key  INT          NOT NULL,   -- 201910 (sort helper)
    day_of_month    TINYINT      NOT NULL,
    day_of_week     TINYINT      NOT NULL,   -- 1 = Monday .. 7 = Sunday
    day_name        VARCHAR(10)  NOT NULL,
    day_short       CHAR(3)      NOT NULL,
    day_type        VARCHAR(7)   NOT NULL,   -- Weekday / Weekend
    CONSTRAINT pk_dim_date PRIMARY KEY (date_key)
);
GO

-------------------------------------------------------------------------------
-- dim_customer : one row per client (key = source client id)
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_customer (
    customer_key        INT            NOT NULL,
    gender              VARCHAR(10),
    current_age         TINYINT,
    age_group           VARCHAR(10),
    age_group_sort      TINYINT,
    birth_year          SMALLINT,
    retirement_age      TINYINT,
    yearly_income       DECIMAL(12,2),
    income_band         VARCHAR(10),
    income_band_sort    TINYINT,
    per_capita_income   DECIMAL(12,2),
    total_debt          DECIMAL(12,2),
    credit_score        SMALLINT,
    credit_band         VARCHAR(10),
    credit_band_sort    TINYINT,
    num_credit_cards    TINYINT,
    latitude            DECIMAL(8,4),
    longitude           DECIMAL(8,4),
    CONSTRAINT pk_dim_customer PRIMARY KEY (customer_key)
);
GO

-------------------------------------------------------------------------------
-- dim_card : one row per card (key = source card id)
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_card (
    card_key               INT            NOT NULL,
    customer_key           INT,
    card_brand             VARCHAR(20),
    card_type              VARCHAR(20),
    has_chip               VARCHAR(3),    -- Yes / No
    num_cards_issued       TINYINT,
    credit_limit           DECIMAL(12,2),
    acct_open_date         DATE,
    acct_open_year         SMALLINT,
    expires_date           DATE,
    year_pin_last_changed  SMALLINT,
    CONSTRAINT pk_dim_card PRIMARY KEY (card_key)
);
GO

-------------------------------------------------------------------------------
-- dim_mcc : merchant category (key = MCC code) + a broader category group
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_mcc (
    mcc_key          SMALLINT      NOT NULL,
    mcc_description  VARCHAR(100),
    mcc_category     VARCHAR(40),
    CONSTRAINT pk_dim_mcc PRIMARY KEY (mcc_key)
);
GO

-------------------------------------------------------------------------------
-- dim_location : where the merchant is (surrogate key)
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_location (
    location_key   INT IDENTITY(1,1) NOT NULL,
    location_type  VARCHAR(15)   NOT NULL,   -- Online / United States / International
    country        VARCHAR(50)   NOT NULL,   -- 'Online' for online merchants
    state          CHAR(2),                  -- US only
    city           VARCHAR(50)   NOT NULL,
    zip            CHAR(5),                  -- US only
    location_code  VARCHAR(150)  NOT NULL,   -- business key used by the fact load
    CONSTRAINT pk_dim_location PRIMARY KEY (location_key)
);
GO

-------------------------------------------------------------------------------
-- dim_channel : Swipe / Chip / Online
-------------------------------------------------------------------------------
CREATE TABLE gold.dim_channel (
    channel_key   TINYINT      NOT NULL,
    channel_name  VARCHAR(10)  NOT NULL,
    CONSTRAINT pk_dim_channel PRIMARY KEY (channel_key)
);
GO

-------------------------------------------------------------------------------
-- fact_transactions : one row per transaction (13.3M rows)
-------------------------------------------------------------------------------
CREATE TABLE gold.fact_transactions (
    transaction_id    INT            NOT NULL,
    date_key          INT            NOT NULL,
    transaction_hour  TINYINT        NOT NULL,
    customer_key      INT            NOT NULL,
    card_key          INT            NOT NULL,
    location_key      INT            NOT NULL,
    mcc_key           SMALLINT       NOT NULL,
    channel_key       TINYINT        NOT NULL,
    merchant_id       INT            NOT NULL,
    amount            DECIMAL(12,2)  NOT NULL,
    is_refund         TINYINT        NOT NULL,   -- 1 = negative amount
    has_error         TINYINT        NOT NULL,   -- 1 = at least one error
    fraud_status      VARCHAR(10)    NOT NULL,   -- Fraud / Legit / Unlabeled
    is_fraud          TINYINT        NULL        -- 1 / 0 / NULL when no label
);
GO

-- Columnstore: smaller table and fast aggregations for Power BI
CREATE CLUSTERED COLUMNSTORE INDEX cci_fact_transactions ON gold.fact_transactions;
GO

-------------------------------------------------------------------------------
-- fact_transaction_errors : one row per transaction per error type
-------------------------------------------------------------------------------
CREATE TABLE gold.fact_transaction_errors (
    transaction_id  INT            NOT NULL,
    error_type      VARCHAR(50)    NOT NULL,
    date_key        INT            NOT NULL,
    customer_key    INT            NOT NULL,
    card_key        INT            NOT NULL,
    location_key    INT            NOT NULL,
    mcc_key         SMALLINT       NOT NULL,
    channel_key     TINYINT        NOT NULL,
    amount          DECIMAL(12,2)  NOT NULL
);
GO
