/*
===============================================================================
 Stored Procedure: Load Bronze Layer (Source files -> Bronze)
===============================================================================
 Purpose:
   Full load of the 5 source files into the bronze tables.
   For each table it truncates the table, loads the file as-is, then prints
   the row count and how long it took.
     - CSV files  : BULK INSERT
     - JSON files : OPENROWSET(BULK ...) + OPENJSON

 Parameter:
   @data_path : folder that has the 5 source files.
                Default = C:\DWH\datasets\

 Usage:
   EXEC bronze.load_bronze;
   EXEC bronze.load_bronze @data_path = N'D:\data\finance\';

 Source file notes (checked on the raw files):
   - users_data.csv, transactions_data.csv : lines end with LF   -> ROWTERMINATOR = '0x0a'
   - cards_data.csv                        : lines end with CRLF -> ROWTERMINATOR = '\r\n'
     (with '0x0a' a hidden CR char would stay at the end of the last column)
   - 941 transactions have more than one error inside quotes,
     for example "Bad PIN,Insufficient Balance".
     FORMAT = 'CSV' reads quoted values correctly (needs SQL Server 2017 or newer).
===============================================================================
*/

USE FinanceDWH;
GO

CREATE OR ALTER PROCEDURE bronze.load_bronze
    @data_path NVARCHAR(260) = N'C:\DWH\datasets\'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @path        NVARCHAR(260),
            @sql         NVARCHAR(MAX),
            @row_count   BIGINT,
            @start_time  DATETIME2(0),
            @batch_start DATETIME2(0) = SYSDATETIME();

    -- The folder must end with '\'.
    -- Single quotes are doubled because the path goes inside dynamic SQL.
    SET @path = @data_path + CASE WHEN RIGHT(@data_path, 1) = N'\' THEN N'' ELSE N'\' END;
    SET @path = REPLACE(@path, N'''', N'''''');

    BEGIN TRY
        PRINT '===============================================';
        PRINT 'Loading Bronze Layer from: ' + @data_path;
        PRINT '===============================================';

        -----------------------------------------------------------------------
        -- 1) users_data.csv  (lines end with LF)
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE bronze.users_data;

        SET @sql = N'
            BULK INSERT bronze.users_data
            FROM ''' + @path + N'users_data.csv''
            WITH (
                FORMAT          = ''CSV'',
                FIRSTROW        = 2,
                FIELDTERMINATOR = '','',
                FIELDQUOTE      = ''"'',
                ROWTERMINATOR   = ''0x0a'',
                TABLOCK
            );';
        EXEC sp_executesql @sql;

        SELECT @row_count = COUNT_BIG(*) FROM bronze.users_data;
        PRINT '>> bronze.users_data         : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 2) cards_data.csv  (lines end with CRLF)
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE bronze.cards_data;

        SET @sql = N'
            BULK INSERT bronze.cards_data
            FROM ''' + @path + N'cards_data.csv''
            WITH (
                FORMAT          = ''CSV'',
                FIRSTROW        = 2,
                FIELDTERMINATOR = '','',
                FIELDQUOTE      = ''"'',
                ROWTERMINATOR   = ''\r\n'',
                TABLOCK
            );';
        EXEC sp_executesql @sql;

        SELECT @row_count = COUNT_BIG(*) FROM bronze.cards_data;
        PRINT '>> bronze.cards_data         : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 3) transactions_data.csv  (lines end with LF, 1.26 GB)
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE bronze.transactions_data;

        SET @sql = N'
            BULK INSERT bronze.transactions_data
            FROM ''' + @path + N'transactions_data.csv''
            WITH (
                FORMAT          = ''CSV'',
                FIRSTROW        = 2,
                FIELDTERMINATOR = '','',
                FIELDQUOTE      = ''"'',
                ROWTERMINATOR   = ''0x0a'',
                TABLOCK
            );';
        EXEC sp_executesql @sql;

        SELECT @row_count = COUNT_BIG(*) FROM bronze.transactions_data;
        PRINT '>> bronze.transactions_data  : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 4) mcc_codes.json  ->  {"5812": "Eating Places and Restaurants", ...}
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE bronze.mcc_codes;

        SET @sql = N'
            INSERT INTO bronze.mcc_codes (mcc, description)
            SELECT j.[key], j.[value]
            FROM OPENROWSET(BULK ''' + @path + N'mcc_codes.json'', SINGLE_CLOB) AS f
            CROSS APPLY OPENJSON(f.BulkColumn) AS j;';
        EXEC sp_executesql @sql;

        SELECT @row_count = COUNT_BIG(*) FROM bronze.mcc_codes;
        PRINT '>> bronze.mcc_codes          : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 5) train_fraud_labels.json  ->  {"target": {"10649266": "No", ...}}
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE bronze.train_fraud_labels;

        SET @sql = N'
            INSERT INTO bronze.train_fraud_labels WITH (TABLOCK) (transaction_id, is_fraud)
            SELECT j.[key], j.[value]
            FROM OPENROWSET(BULK ''' + @path + N'train_fraud_labels.json'', SINGLE_CLOB) AS f
            CROSS APPLY OPENJSON(f.BulkColumn, ''$.target'') AS j;';
        EXEC sp_executesql @sql;

        SELECT @row_count = COUNT_BIG(*) FROM bronze.train_fraud_labels;
        PRINT '>> bronze.train_fraud_labels : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        PRINT '===============================================';
        PRINT 'Bronze Layer loaded in '
              + CAST(DATEDIFF(SECOND, @batch_start, SYSDATETIME()) AS VARCHAR(20)) + ' sec';
        PRINT '===============================================';
    END TRY
    BEGIN CATCH
        PRINT '===============================================';
        PRINT 'ERROR while loading the Bronze Layer';
        PRINT 'Message : ' + ERROR_MESSAGE();
        PRINT 'Number  : ' + CAST(ERROR_NUMBER() AS VARCHAR(20));
        PRINT '===============================================';
        THROW;
    END CATCH
END;
GO
