/*
===============================================================================
 DDL Script: Create Bronze Tables
===============================================================================
 Purpose:
   Creates one bronze table per source file. Bronze is a raw copy of the files:
   every column is VARCHAR, so values land exactly as they are in the source
   (for example '$-77.00', '58523.0', '09/2002'). Data types and cleaning
   happen later in the Silver layer.

 Warning:
   Re-running this script drops and re-creates the bronze tables.
   Reload them after that with: EXEC bronze.load_bronze;
===============================================================================
*/

USE FinanceDWH;
GO

-------------------------------------------------------------------------------
-- users_data.csv : 2,000 rows, one row per client
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS bronze.users_data;
GO

CREATE TABLE bronze.users_data (
    id                 VARCHAR(10),
    current_age        VARCHAR(10),
    retirement_age     VARCHAR(10),
    birth_year         VARCHAR(10),
    birth_month        VARCHAR(10),
    gender             VARCHAR(20),
    address            VARCHAR(100),
    latitude           VARCHAR(20),
    longitude          VARCHAR(20),
    per_capita_income  VARCHAR(20),
    yearly_income      VARCHAR(20),
    total_debt         VARCHAR(20),
    credit_score       VARCHAR(10),
    num_credit_cards   VARCHAR(10)
);
GO

-------------------------------------------------------------------------------
-- cards_data.csv : 6,146 rows, one row per card
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS bronze.cards_data;
GO

CREATE TABLE bronze.cards_data (
    id                     VARCHAR(10),
    client_id              VARCHAR(10),
    card_brand             VARCHAR(20),
    card_type              VARCHAR(30),
    card_number            VARCHAR(25),
    expires                VARCHAR(10),
    cvv                    VARCHAR(10),
    has_chip               VARCHAR(10),
    num_cards_issued       VARCHAR(10),
    credit_limit           VARCHAR(20),
    acct_open_date         VARCHAR(10),
    year_pin_last_changed  VARCHAR(10),
    card_on_dark_web       VARCHAR(10)
);
GO

-------------------------------------------------------------------------------
-- transactions_data.csv : 13,305,915 rows, one row per transaction
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS bronze.transactions_data;
GO

CREATE TABLE bronze.transactions_data (
    id              VARCHAR(15),
    [date]          VARCHAR(25),
    client_id       VARCHAR(10),
    card_id         VARCHAR(10),
    amount          VARCHAR(20),
    use_chip        VARCHAR(30),
    merchant_id     VARCHAR(10),
    merchant_city   VARCHAR(50),
    merchant_state  VARCHAR(50),
    zip             VARCHAR(10),
    mcc             VARCHAR(10),
    errors          VARCHAR(100)
);
GO

-------------------------------------------------------------------------------
-- mcc_codes.json : 109 rows, merchant category code -> description
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS bronze.mcc_codes;
GO

CREATE TABLE bronze.mcc_codes (
    mcc          VARCHAR(10),
    description  VARCHAR(100)
);
GO

-------------------------------------------------------------------------------
-- train_fraud_labels.json : 8,914,963 rows, transaction id -> 'Yes' / 'No'
-------------------------------------------------------------------------------
DROP TABLE IF EXISTS bronze.train_fraud_labels;
GO

CREATE TABLE bronze.train_fraud_labels (
    transaction_id  VARCHAR(15),
    is_fraud        VARCHAR(10)
);
GO
