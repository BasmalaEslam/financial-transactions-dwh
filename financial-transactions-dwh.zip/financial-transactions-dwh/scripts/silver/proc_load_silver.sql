/*
===============================================================================
 Stored Procedure: Load Silver Layer (Bronze -> Silver)
===============================================================================
 Purpose:
   Full load of the silver tables from bronze. For each table it truncates
   the table, inserts cleaned rows, then prints the row count and the time.

 Cleaning rules (see docs/bronze_notes.md for the numbers):
   users         : text -> numbers, '$' removed, per_capita_income 0 -> NULL
   cards         : 'YES'/'NO' -> BIT, 'MM/YYYY' -> DATE, '$' removed,
                   card_number / cvv / card_on_dark_web dropped
   transactions  : '$' removed, is_refund flag (amount < 0),
                   'Swipe Transaction' -> 'Swipe' (same for Chip / Online),
                   'ONLINE' city -> is_online flag + location_type,
                   merchant_state split into state (US code) and country,
                   ZIP '2860.0' -> '02860', empty errors -> NULL + has_error flag
   mcc_codes     : code -> SMALLINT
   fraud_labels  : 'Yes'/'No' -> BIT
   transaction_errors : one row per error ('Bad PIN,Insufficient Balance' -> 2 rows)

 Usage:
   EXEC silver.load_silver;
===============================================================================
*/

USE FinanceDWH;
GO

CREATE OR ALTER PROCEDURE silver.load_silver
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @row_count   BIGINT,
            @start_time  DATETIME2(0),
            @batch_start DATETIME2(0) = SYSDATETIME();

    BEGIN TRY
        PRINT '===============================================';
        PRINT 'Loading Silver Layer';
        PRINT '===============================================';

        -----------------------------------------------------------------------
        -- 1) silver.users
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.users;

        INSERT INTO silver.users WITH (TABLOCK) (
            customer_id, current_age, retirement_age, birth_year, birth_month,
            gender, address, latitude, longitude,
            per_capita_income, yearly_income, total_debt,
            credit_score, num_credit_cards
        )
        SELECT
            TRY_CAST(TRIM(id)             AS INT),
            TRY_CAST(TRIM(current_age)    AS TINYINT),
            TRY_CAST(TRIM(retirement_age) AS TINYINT),
            TRY_CAST(TRIM(birth_year)     AS SMALLINT),
            TRY_CAST(TRIM(birth_month)    AS TINYINT),
            TRIM(gender),
            TRIM(address),
            TRY_CAST(TRIM(latitude)       AS DECIMAL(8,4)),
            TRY_CAST(TRIM(longitude)      AS DECIMAL(8,4)),
            NULLIF(TRY_CAST(REPLACE(TRIM(per_capita_income), '$', '') AS DECIMAL(12,2)), 0),
            TRY_CAST(REPLACE(TRIM(yearly_income), '$', '') AS DECIMAL(12,2)),
            TRY_CAST(REPLACE(TRIM(total_debt),    '$', '') AS DECIMAL(12,2)),
            TRY_CAST(TRIM(credit_score)     AS SMALLINT),
            TRY_CAST(TRIM(num_credit_cards) AS TINYINT)
        FROM bronze.users_data;

        SELECT @row_count = COUNT_BIG(*) FROM silver.users;
        PRINT '>> silver.users              : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 2) silver.cards
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.cards;

        INSERT INTO silver.cards WITH (TABLOCK) (
            card_id, customer_id, card_brand, card_type, has_chip,
            num_cards_issued, credit_limit, expires_date, acct_open_date,
            year_pin_last_changed
        )
        SELECT
            TRY_CAST(TRIM(id)        AS INT),
            TRY_CAST(TRIM(client_id) AS INT),
            TRIM(card_brand),
            TRIM(card_type),
            CASE UPPER(TRIM(has_chip)) WHEN 'YES' THEN 1 WHEN 'NO' THEN 0 END,
            TRY_CAST(TRIM(num_cards_issued) AS TINYINT),
            TRY_CAST(REPLACE(TRIM(credit_limit), '$', '') AS DECIMAL(12,2)),
            -- 'MM/YYYY' -> last day of that month
            EOMONTH(DATEFROMPARTS(TRY_CAST(RIGHT(TRIM(expires), 4) AS INT),
                                  TRY_CAST(LEFT(TRIM(expires), 2)  AS INT), 1)),
            -- 'MM/YYYY' -> first day of that month
            DATEFROMPARTS(TRY_CAST(RIGHT(TRIM(acct_open_date), 4) AS INT),
                          TRY_CAST(LEFT(TRIM(acct_open_date), 2)  AS INT), 1),
            TRY_CAST(TRIM(year_pin_last_changed) AS SMALLINT)
        FROM bronze.cards_data;

        SELECT @row_count = COUNT_BIG(*) FROM silver.cards;
        PRINT '>> silver.cards              : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 3) silver.transactions  (13.3M rows)
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.transactions;

        INSERT INTO silver.transactions WITH (TABLOCK) (
            transaction_id, transaction_datetime, transaction_date,
            customer_id, card_id, amount, is_refund, channel, merchant_id,
            is_online, location_type, merchant_city, merchant_state, merchant_zip,
            merchant_country, mcc, errors, has_error
        )
        SELECT
            TRY_CAST(TRIM(t.id) AS INT),
            v.tx_datetime,
            CAST(v.tx_datetime AS DATE),
            TRY_CAST(TRIM(t.client_id) AS INT),
            TRY_CAST(TRIM(t.card_id)   AS INT),
            v.amount,
            CASE WHEN v.amount < 0 THEN 1 ELSE 0 END,
            CASE TRIM(t.use_chip)
                WHEN 'Swipe Transaction'  THEN 'Swipe'
                WHEN 'Chip Transaction'   THEN 'Chip'
                WHEN 'Online Transaction' THEN 'Online'
                ELSE 'Unknown'
            END,
            TRY_CAST(TRIM(t.merchant_id) AS INT),
            v.is_online,
            CASE
                WHEN v.is_online = 1                 THEN 'Online'
                WHEN LEN(TRIM(t.merchant_state)) = 2 THEN 'United States'
                ELSE 'International'
            END,
            CASE WHEN v.is_online = 1 THEN 'Online' ELSE TRIM(t.merchant_city) END,
            -- the source column holds a US state code OR a country name
            CASE WHEN LEN(TRIM(t.merchant_state)) = 2 THEN TRIM(t.merchant_state) END,
            -- ZIP was stored like a decimal: '2860.0' -> '02860'
            CASE WHEN NULLIF(TRIM(t.zip), '') IS NOT NULL
                 THEN RIGHT('00000' + LEFT(TRIM(t.zip), CHARINDEX('.', TRIM(t.zip) + '.') - 1), 5)
            END,
            CASE
                WHEN v.is_online = 1                 THEN NULL
                WHEN LEN(TRIM(t.merchant_state)) = 2 THEN 'United States'
                ELSE TRIM(t.merchant_state)
            END,
            TRY_CAST(TRIM(t.mcc) AS SMALLINT),
            NULLIF(TRIM(t.errors), ''),
            CASE WHEN NULLIF(TRIM(t.errors), '') IS NULL THEN 0 ELSE 1 END
        FROM bronze.transactions_data AS t
        CROSS APPLY (
            SELECT
                TRY_CONVERT(DATETIME2(0), TRIM(t.[date]), 120)              AS tx_datetime,
                TRY_CAST(REPLACE(TRIM(t.amount), '$', '') AS DECIMAL(12,2)) AS amount,
                CASE WHEN UPPER(TRIM(t.merchant_city)) = 'ONLINE' THEN 1 ELSE 0 END AS is_online
        ) AS v;

        SELECT @row_count = COUNT_BIG(*) FROM silver.transactions;
        PRINT '>> silver.transactions       : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 4) silver.mcc_codes
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.mcc_codes;

        INSERT INTO silver.mcc_codes (mcc, description)
        SELECT
            TRY_CAST(TRIM(mcc) AS SMALLINT),
            TRIM(description)
        FROM bronze.mcc_codes;

        SELECT @row_count = COUNT_BIG(*) FROM silver.mcc_codes;
        PRINT '>> silver.mcc_codes          : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 5) silver.fraud_labels
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.fraud_labels;

        INSERT INTO silver.fraud_labels WITH (TABLOCK) (transaction_id, is_fraud)
        SELECT
            TRY_CAST(TRIM(transaction_id) AS INT),
            CASE TRIM(is_fraud) WHEN 'Yes' THEN 1 WHEN 'No' THEN 0 END
        FROM bronze.train_fraud_labels;

        SELECT @row_count = COUNT_BIG(*) FROM silver.fraud_labels;
        PRINT '>> silver.fraud_labels       : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        -----------------------------------------------------------------------
        -- 6) silver.transaction_errors  (split the multi-value errors)
        -----------------------------------------------------------------------
        SET @start_time = SYSDATETIME();
        TRUNCATE TABLE silver.transaction_errors;

        INSERT INTO silver.transaction_errors WITH (TABLOCK) (transaction_id, error_type)
        SELECT
            t.transaction_id,
            TRIM(s.value)
        FROM silver.transactions AS t
        CROSS APPLY STRING_SPLIT(t.errors, ',') AS s
        WHERE t.errors IS NOT NULL
          AND TRIM(s.value) <> '';

        SELECT @row_count = COUNT_BIG(*) FROM silver.transaction_errors;
        PRINT '>> silver.transaction_errors : ' + CAST(@row_count AS VARCHAR(20)) + ' rows ('
              + CAST(DATEDIFF(SECOND, @start_time, SYSDATETIME()) AS VARCHAR(20)) + ' sec)';

        PRINT '===============================================';
        PRINT 'Silver Layer loaded in '
              + CAST(DATEDIFF(SECOND, @batch_start, SYSDATETIME()) AS VARCHAR(20)) + ' sec';
        PRINT '===============================================';
    END TRY
    BEGIN CATCH
        PRINT '===============================================';
        PRINT 'ERROR while loading the Silver Layer';
        PRINT 'Message : ' + ERROR_MESSAGE();
        PRINT 'Number  : ' + CAST(ERROR_NUMBER() AS VARCHAR(20));
        PRINT '===============================================';
        THROW;
    END CATCH
END;
GO
