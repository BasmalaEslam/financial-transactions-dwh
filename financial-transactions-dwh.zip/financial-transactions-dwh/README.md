# Financial Transactions Data Warehouse

An end-to-end data warehouse on **13.3 million card transactions (Jan 2010 to Oct 2019)**, built in **SQL Server** with a **Bronze / Silver / Gold** (medallion) design, and a **4-page Power BI dashboard** on top of the gold star schema.

![Architecture](docs/architecture.png)

## What is inside

| Layer | What happens | Objects |
|---|---|---|
| **Bronze** | Raw copy of the 5 source files. CSV with `BULK INSERT`, JSON with `OPENROWSET` + `OPENJSON`. Every column is `VARCHAR`, values are not changed. | 5 tables, `bronze.load_bronze` |
| **Silver** | Cleaned and typed data: `$` removed, dates parsed, ZIP codes fixed, state and country split, multi-value errors split, sensitive card data dropped. | 6 tables, `silver.load_silver` |
| **Gold** | Star schema: 6 dimensions shared by 2 fact tables. Clustered columnstore on the main fact. | 8 tables, `gold.load_gold` |
| **Power BI** | Import model on the gold tables, 30 DAX measures (9 of them return a text insight), custom Neon Violet theme, 4 report pages. | `powerbi/FinanceDWH.pbip` |

58 automated quality checks (row counts, duplicates, NULLs after conversion, orphan keys and business totals) run after each layer.

## Source data

Kaggle financial transactions dataset (5 files).
<!-- Add the Kaggle link of the dataset here -->

| File | Rows | Notes |
|---|---:|---|
| `transactions_data.csv` | 13,305,915 | 1.26 GB, one row per card transaction |
| `users_data.csv` | 2,000 | one row per client |
| `cards_data.csv` | 6,146 | one row per card |
| `mcc_codes.json` | 109 | merchant category code to description |
| `train_fraud_labels.json` | 8,914,963 | `Yes` / `No` per transaction (13,332 `Yes`) |

All keys match 100% between the files (see [docs/bronze_notes.md](docs/bronze_notes.md)).

## Data quality: what Silver fixes

| Problem in the raw data | Rows | Fix |
|---|---:|---|
| Money stored as text with `$` (`$-77.00`) | all | `DECIMAL(12,2)`, refunds flagged (`amount < 0`, 660,049 rows) |
| ZIP stored like a decimal (`2860.0`) | 803,000 lost a leading zero | `CHAR(5)` with zeros restored (`02860`) |
| `merchant_state` holds a US state **or** a country name | 89,006 international | split into `merchant_state` and `merchant_country` |
| Online merchants have city `ONLINE` and no state or ZIP | 1,563,700 | `is_online` flag and `location_type` |
| Several errors in one value (`"Bad PIN,Insufficient Balance"`) | 941 | split into `silver.transaction_errors` (one row per error) |
| `per_capita_income = 0` | 15 clients | set to `NULL` (unknown) |
| `card_number`, `cvv` (sensitive), `card_on_dark_web` (always `No`) | all cards | not carried to Silver |
| Fraud labels missing for part of the data | 4,390,952 | kept as `Unlabeled`, fraud rate uses labeled rows only |

## Gold star schema

![Star schema](docs/star_schema.png)

Column details: [docs/data_catalog.md](docs/data_catalog.md)

## Dashboard

"Finance Hub" report in a dark neon style (**Neon Violet**): deep purple background with violet, pink and cyan. Each page has its own accent color (Overview violet, Customers pink, Merchants cyan, Fraud red). Every page has the same header with icon navigation, a filter panel and a row of 6 KPI cards:

- **Number cards** show the value and a small trend line of the same measure by year.
- **Insight cards** (2 per page) use a DAX measure that returns a short answer, for example *Riskiest Channel: Online*. They update with every filter.
- Channels, location types, card types and genders keep the same color on every chart.

| Page | KPI cards | Charts |
|---|---|---|
| **Executive Overview** | Total Transactions, Total Amount, Avg Transaction, Refund Rate, *Busiest Hour*, *Top Channel* | Amount by year, channel mix by year, amount by category, transactions by channel and by hour |
| **Customers & Cards** | Active Customers, Active Cards, Spend per Customer, Avg Credit Score, *Top Age Group*, *Top Card Brand* | Amount by age group and gender, customers by credit band, amount by card brand and type, top customers |
| **Merchants & Locations** | Active Merchants, Online Share, Intl Transactions, Avg Transaction, *Top US State*, *Top Country Abroad* | Top US states, cities and merchant types, amount by location type, international transactions by country |
| **Fraud & Errors** | Fraud Rate, Fraud Transactions, Error Rate, *Riskiest Channel*, *Top Fraud Country*, *Peak Fraud Hour* | Fraud rate by hour, channel, location and category, fraud by country, errors by type |

Filters (button slicers synced across pages): Year, Channel, Location Type, Card Type, Gender.
The page backgrounds (header, navigation, card frames, icons and chart titles) are images in `powerbi/FinanceDWH.Report/StaticResources/RegisteredResources/`. Invisible Power BI buttons sit on top of the navigation (Ctrl + click in Power BI Desktop).

## Key insights

- **Chip cards took over in 2015.** Chip went from 0% of transactions (2010 to 2014) to about 71% (2015 onward), while swipe fell from about 89% to 17%.
- **Online is the risky channel.** Fraud rate is 0.84% online vs 0.10% chip and 0.03% swipe (about 29x swipe).
- **International purchases are the riskiest location.** 5.58% fraud rate vs 0.84% online and 0.016% in the US. Italy alone has 3,061 of the 3,319 international fraud cases.
- **Fraud peaks late morning.** 0.22% to 0.26% between 10:00 and 14:00, and below 0.02% after 20:00.
- **Insufficient Balance** is 62% of all transaction errors (131,621 of 212,335).
- **Groceries & Food Stores** is the largest category by amount ($95.6M). **Electronics & Digital** has the highest fraud rate (2.45%).

## How to run

Requirements: SQL Server 2017 or newer, SSMS, a recent Power BI Desktop (it must open `.pbip` projects).

1. Put the 5 source files in `C:\DWH\datasets\`.
2. In SSMS open `scripts/build_full_dwh.sql` and press **F5**. It creates the database `FinanceDWH`, loads Bronze, Silver and Gold, and runs all quality checks (every row should say `OK`).
   Data somewhere else? Change the folder in the `@data_path` line.
3. Open `powerbi/FinanceDWH.pbip` in Power BI Desktop.
   **Home > Transform data > Edit parameters**: set `SqlServer` to the same server name you use in SSMS (for example `localhost` or `localhost\SQLEXPRESS`), then **Apply changes**.
   If Power BI asks for credentials, choose **Windows > Use my current credentials**. The first load imports 13.3M rows, so give it some time.

You can also run each layer on its own:

```sql
EXEC bronze.load_bronze @data_path = N'C:\DWH\datasets\';
EXEC silver.load_silver;
EXEC gold.load_gold;
```

## Repository structure

```
financial-transactions-dwh/
├── scripts/
│   ├── build_full_dwh.sql        one-click build (all scripts + ETL + checks)
│   ├── init_database.sql         database + bronze/silver/gold schemas
│   ├── bronze/                   ddl_bronze.sql, proc_load_bronze.sql
│   ├── silver/                   ddl_silver.sql, proc_load_silver.sql
│   └── gold/                     ddl_gold.sql, proc_load_gold.sql
├── tests/                        quality_checks_bronze / silver / gold.sql
├── powerbi/                      FinanceDWH.pbip (TMDL model + PBIR report)
└── docs/                         architecture, star schema, data catalog, notes
```

## Tools

SQL Server · T-SQL · SSMS · Power BI Desktop · Power Query (M) · DAX · PBIP / TMDL
