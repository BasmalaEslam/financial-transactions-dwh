/*
===============================================================================
 Quality Checks: Silver Layer
===============================================================================
 Run after: EXEC silver.load_silver;
 Every row should show result = 'OK'.
 Expected numbers were counted from the raw files with the same rules.
===============================================================================
*/

USE FinanceDWH;
GO

SELECT check_id,
       check_name,
       expected,
       actual,
       CASE WHEN expected = actual THEN 'OK' ELSE 'CHECK' END AS result
FROM (
    ---------------------------------------------------------------------------
    -- Row counts
    ---------------------------------------------------------------------------
    SELECT 1 AS check_id, 'users: row count' AS check_name,
           CAST(2000 AS BIGINT) AS expected,
           (SELECT COUNT_BIG(*) FROM silver.users) AS actual
    UNION ALL
    SELECT 2, 'cards: row count', 6146,
           (SELECT COUNT_BIG(*) FROM silver.cards)
    UNION ALL
    SELECT 3, 'transactions: row count', 13305915,
           (SELECT COUNT_BIG(*) FROM silver.transactions)
    UNION ALL
    SELECT 4, 'mcc_codes: row count', 109,
           (SELECT COUNT_BIG(*) FROM silver.mcc_codes)
    UNION ALL
    SELECT 5, 'fraud_labels: row count', 8914963,
           (SELECT COUNT_BIG(*) FROM silver.fraud_labels)
    UNION ALL
    SELECT 6, 'transaction_errors: row count (one per error)', 212335,
           (SELECT COUNT_BIG(*) FROM silver.transaction_errors)

    ---------------------------------------------------------------------------
    -- Duplicates
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 7, 'users: duplicate customer_id', 0,
           (SELECT COUNT_BIG(*) - COUNT_BIG(DISTINCT customer_id) FROM silver.users)
    UNION ALL
    SELECT 8, 'cards: duplicate card_id', 0,
           (SELECT COUNT_BIG(*) - COUNT_BIG(DISTINCT card_id) FROM silver.cards)
    UNION ALL
    SELECT 9, 'transactions: duplicate transaction_id', 0,
           (SELECT COUNT_BIG(*) - COUNT_BIG(DISTINCT transaction_id) FROM silver.transactions)

    ---------------------------------------------------------------------------
    -- NULLs after type conversion (a failed TRY_CAST becomes NULL)
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 10, 'users: NULL in converted columns', 0,
           (SELECT COUNT_BIG(*) FROM silver.users
            WHERE current_age IS NULL OR yearly_income IS NULL OR total_debt IS NULL
               OR credit_score IS NULL OR latitude IS NULL OR longitude IS NULL)
    UNION ALL
    SELECT 11, 'users: per_capita_income NULL (was 0 in source)', 15,
           (SELECT COUNT_BIG(*) FROM silver.users WHERE per_capita_income IS NULL)
    UNION ALL
    SELECT 12, 'cards: NULL in converted columns', 0,
           (SELECT COUNT_BIG(*) FROM silver.cards
            WHERE customer_id IS NULL OR has_chip IS NULL OR credit_limit IS NULL
               OR expires_date IS NULL OR acct_open_date IS NULL)
    UNION ALL
    SELECT 13, 'transactions: NULL in converted columns', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions
            WHERE transaction_datetime IS NULL OR amount IS NULL OR customer_id IS NULL
               OR card_id IS NULL OR merchant_id IS NULL OR mcc IS NULL)

    ---------------------------------------------------------------------------
    -- Business rules
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 14, 'transactions: total amount in cents', 57183552228,
           (SELECT CAST(SUM(amount) * 100 AS BIGINT) FROM silver.transactions)
    UNION ALL
    SELECT 15, 'transactions: refunds (amount < 0)', 660049,
           (SELECT COUNT_BIG(*) FROM silver.transactions WHERE is_refund = 1)
    UNION ALL
    SELECT 16, 'transactions: online', 1563700,
           (SELECT COUNT_BIG(*) FROM silver.transactions WHERE location_type = 'Online')
    UNION ALL
    SELECT 17, 'transactions: international', 89006,
           (SELECT COUNT_BIG(*) FROM silver.transactions WHERE location_type = 'International')
    UNION ALL
    SELECT 18, 'transactions: US rows without state or 5-digit ZIP', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions
            WHERE location_type = 'United States'
              AND (merchant_state IS NULL OR merchant_zip IS NULL OR merchant_zip LIKE '%[^0-9]%'))
    UNION ALL
    SELECT 19, 'transactions: with at least one error', 211393,
           (SELECT COUNT_BIG(*) FROM silver.transactions WHERE has_error = 1)
    UNION ALL
    SELECT 20, 'transactions: unknown channel', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions WHERE channel = 'Unknown')
    UNION ALL
    SELECT 21, 'fraud_labels: is_fraud = 1', 13332,
           (SELECT COUNT_BIG(*) FROM silver.fraud_labels WHERE is_fraud = 1)

    ---------------------------------------------------------------------------
    -- Relationships between tables
    ---------------------------------------------------------------------------
    UNION ALL
    SELECT 22, 'transactions: customer not in users', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions AS t
            WHERE NOT EXISTS (SELECT 1 FROM silver.users AS u WHERE u.customer_id = t.customer_id))
    UNION ALL
    SELECT 23, 'transactions: card not in cards', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions AS t
            WHERE NOT EXISTS (SELECT 1 FROM silver.cards AS c WHERE c.card_id = t.card_id))
    UNION ALL
    SELECT 24, 'transactions: card owner <> transaction customer', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions AS t
            JOIN silver.cards AS c ON c.card_id = t.card_id
            WHERE c.customer_id <> t.customer_id)
    UNION ALL
    SELECT 25, 'transactions: mcc not in mcc_codes', 0,
           (SELECT COUNT_BIG(*) FROM silver.transactions AS t
            WHERE NOT EXISTS (SELECT 1 FROM silver.mcc_codes AS m WHERE m.mcc = t.mcc))
    UNION ALL
    SELECT 26, 'fraud_labels: transaction not found', 0,
           (SELECT COUNT_BIG(*) FROM silver.fraud_labels AS f
            WHERE NOT EXISTS (SELECT 1 FROM silver.transactions AS t WHERE t.transaction_id = f.transaction_id))
) AS c
ORDER BY check_id;
GO
