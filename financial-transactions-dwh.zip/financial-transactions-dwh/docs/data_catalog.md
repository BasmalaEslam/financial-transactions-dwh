# Data Catalog: Gold Layer

The gold layer is a star schema in the `gold` schema of the `FinanceDWH` database.
Two fact tables share the same six dimensions.

## gold.fact_transactions

One row per card transaction (13,305,915 rows). Clustered columnstore index.

| Column | Type | Description |
|---|---|---|
| transaction_id | INT | Source transaction id |
| date_key | INT | Transaction date as `yyyymmdd`, joins `dim_date` |
| transaction_hour | TINYINT | Hour of the transaction (0 to 23) |
| customer_key | INT | Joins `dim_customer` |
| card_key | INT | Joins `dim_card` |
| location_key | INT | Joins `dim_location` |
| mcc_key | SMALLINT | Merchant category code, joins `dim_mcc` |
| channel_key | TINYINT | Joins `dim_channel` |
| merchant_id | INT | Source merchant id |
| amount | DECIMAL(12,2) | Amount in USD, negative = refund |
| is_refund | TINYINT | 1 when amount < 0 |
| has_error | TINYINT | 1 when the transaction has at least one error |
| fraud_status | VARCHAR(10) | `Fraud`, `Legit` or `Unlabeled` (no label in the source) |
| is_fraud | TINYINT | 1 / 0, NULL when unlabeled |

## gold.fact_transaction_errors

One row per transaction per error type (212,335 rows). A transaction with
`Bad PIN,Insufficient Balance` gives 2 rows.

| Column | Type | Description |
|---|---|---|
| transaction_id | INT | Source transaction id |
| error_type | VARCHAR(50) | For example `Insufficient Balance`, `Bad PIN`, `Technical Glitch` |
| date_key, customer_key, card_key, location_key, mcc_key, channel_key | | Same keys as the transaction |
| amount | DECIMAL(12,2) | Amount of the transaction |

## gold.dim_date (3,652 rows, 2010-01-01 to 2019-12-31)

| Column | Type | Description |
|---|---|---|
| date_key | INT | `yyyymmdd`, primary key |
| full_date | DATE | Calendar date |
| year, quarter, quarter_name | | 2019, 4, `Q4` |
| month_number, month_name, month_short | | 10, `October`, `Oct` |
| year_month, year_month_key | | `2019-10`, 201910 (sort helper) |
| day_of_month, day_of_week, day_name, day_short | | day_of_week: 1 = Monday .. 7 = Sunday |
| day_type | VARCHAR(7) | `Weekday` / `Weekend` |

## gold.dim_customer (2,000 rows)

| Column | Type | Description |
|---|---|---|
| customer_key | INT | Source client id, primary key |
| gender | VARCHAR(10) | `Female` / `Male` |
| current_age, age_group, age_group_sort | | Age groups: 18-24, 25-34, 35-44, 45-54, 55-64, 65+ |
| birth_year, retirement_age | | From the source |
| yearly_income, income_band, income_band_sort | | Bands: <25K, 25K-50K, 50K-75K, 75K-100K, 100K+ |
| per_capita_income, total_debt | DECIMAL(12,2) | USD |
| credit_score, credit_band, credit_band_sort | | FICO ranges: Poor <580, Fair 580-669, Good 670-739, Very Good 740-799, Excellent 800+ |
| num_credit_cards | TINYINT | Number of cards the client has |
| latitude, longitude | DECIMAL(8,4) | Client location |

## gold.dim_card (6,146 rows)

| Column | Type | Description |
|---|---|---|
| card_key | INT | Source card id, primary key |
| customer_key | INT | Card owner |
| card_brand | VARCHAR(20) | Mastercard, Visa, Amex, Discover |
| card_type | VARCHAR(20) | Debit, Credit, Debit (Prepaid) |
| has_chip | VARCHAR(3) | `Yes` / `No` |
| num_cards_issued | TINYINT | From the source |
| credit_limit | DECIMAL(12,2) | USD |
| acct_open_date, acct_open_year | | First day of the opening month |
| expires_date | DATE | Last day of the expiry month |
| year_pin_last_changed | SMALLINT | From the source |

## gold.dim_mcc (109 rows)

| Column | Type | Description |
|---|---|---|
| mcc_key | SMALLINT | Merchant category code, primary key |
| mcc_description | VARCHAR(100) | For example `Grocery Stores, Supermarkets` |
| mcc_category | VARCHAR(40) | One of 14 groups, for example `Groceries & Food Stores` |

## gold.dim_location (25,425 rows)

| Column | Type | Description |
|---|---|---|
| location_key | INT | Surrogate key (IDENTITY), primary key |
| location_type | VARCHAR(15) | `Online`, `United States`, `International` |
| country | VARCHAR(50) | `Online` for online merchants |
| state | CHAR(2) | US state code, NULL outside the US |
| city | VARCHAR(50) | `Online` for online merchants |
| zip | CHAR(5) | US only |
| location_code | VARCHAR(150) | Business key used by the fact load |

## gold.dim_channel (3 rows)

| Column | Type | Description |
|---|---|---|
| channel_key | TINYINT | 1 Swipe, 2 Chip, 3 Online |
| channel_name | VARCHAR(10) | Channel name |
