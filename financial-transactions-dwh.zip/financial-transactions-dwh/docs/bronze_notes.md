# Bronze Layer: Source Data Notes

All numbers below were counted from the raw source files.

## Source files

| File | Rows | Format | Line ending | Bronze table |
|---|---:|---|---|---|
| `users_data.csv` | 2,000 | CSV | LF | `bronze.users_data` |
| `cards_data.csv` | 6,146 | CSV | CRLF | `bronze.cards_data` |
| `transactions_data.csv` | 13,305,915 | CSV (1.26 GB) | LF | `bronze.transactions_data` |
| `mcc_codes.json` | 109 | JSON object: code -> description | - | `bronze.mcc_codes` |
| `train_fraud_labels.json` | 8,914,963 | JSON: `{"target": {transaction_id: "Yes"/"No"}}` | - | `bronze.train_fraud_labels` |

Transactions cover **2010-01-01 to 2019-10-31**.

## How the files connect (common columns)

| From | To | Match |
|---|---|---|
| `transactions_data.client_id` | `users_data.id` | 100% |
| `transactions_data.card_id` | `cards_data.id` | 100% |
| `cards_data.client_id` | `users_data.id` | 100% |
| `transactions_data.mcc` | `mcc_codes` key | 100% (all 109 codes are used) |
| `train_fraud_labels` key | `transactions_data.id` | 100% |

- `id` is unique in users, cards and transactions.
- The card owner (`cards_data.client_id`) always equals the transaction `client_id`.
- 1,219 of 2,000 users and 4,071 of 6,146 cards have transactions.
- Fraud labels exist for 8,914,963 transactions only (about 67%). The other 4,390,952 transactions have no label, so they are "unknown", not "No".

## Raw values kept as-is in Bronze (to handle in Silver)

| Column | Raw example | Note |
|---|---|---|
| `amount` | `$-77.00` | `$` sign. 660,049 negative amounts (likely refunds) and 10,639 zero amounts |
| `per_capita_income`, `yearly_income`, `total_debt`, `credit_limit` | `$29278` | `$` sign, stored as text |
| `zip` | `58523.0` | Stored like a decimal. 803,000 rows lost the leading zero (`2860.0` is ZIP `02860`) |
| `merchant_city`, `merchant_state`, `zip` | `ONLINE`, empty, empty | 1,563,700 online rows have no state and no zip |
| `merchant_state` | `Italy` | 52 values are US codes (50 states, `DC`, `AA`), 147 are country names. 89,006 transactions are outside the US and have no zip |
| `use_chip` vs `merchant_city` | `Swipe Transaction` + `ONLINE` | 5,788 rows have `merchant_city = 'ONLINE'` but `use_chip` is not `Online Transaction` |
| `errors` | `"Bad PIN,Insufficient Balance"` | Empty for 13,094,522 rows. 941 rows hold more than one error in one value |
| `expires`, `acct_open_date` | `09/2002` | Month/year text |
| `has_chip` | `YES` / `NO` | Text flag |
| `card_on_dark_web` | `No` | Same value for all 6,146 cards, no analytical value |
| `card_number`, `cvv` | - | Sensitive card data, do not carry to Silver/Gold |
| `is_fraud` | `Yes` / `No` | Text flag. Only 13,332 `Yes` |
